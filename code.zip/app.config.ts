export default {
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519664066772780/syxNFCwDJXOyrUnt.svg",
};
