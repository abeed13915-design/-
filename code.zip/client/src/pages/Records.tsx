import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import Navbar from "@/components/Navbar";
import CrownHeader from "@/components/CrownHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  formatArabicDateDisplay,
  formatFullArabicDate,
  toArabicNumerals,
} from "@/lib/dateUtils";
import {
  exportAttendanceToExcel,
  exportSessionsToExcel,
  exportToCSV,
  printPage,
} from "@/lib/exportUtils";
import {
  Calendar,
  FileSpreadsheet,
  FileDown,
  Printer,
  Eye,
  Trash2,
  CheckCircle2,
  XCircle,
  PlusCircle,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

export default function Records() {
  const [dateFilter, setDateFilter] = useState<string>("");
  const [hallFilter, setHallFilter] = useState<string>("all");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  const [detailSessionId, setDetailSessionId] = useState<number | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const hallsQ = trpc.attendance.listHalls.useQuery();
  const halls = hallsQ.data ?? [];

  const sessionsQ = trpc.attendance.listSessions.useQuery({
    date: dateFilter || undefined,
    hallId: hallFilter !== "all" ? Number(hallFilter) : undefined,
    fromDate: fromDate || undefined,
    toDate: toDate || undefined,
    limit: 300,
  });
  const sessions = sessionsQ.data ?? [];

  const detailQ = trpc.attendance.sessionDetails.useQuery(
    { sessionId: detailSessionId ?? -1 },
    { enabled: detailSessionId !== null }
  );

  const utils = trpc.useUtils();
  const deleteMutation = trpc.attendance.deleteSession.useMutation({
    onSuccess: () => {
      utils.attendance.listSessions.invalidate();
      utils.attendance.stats.invalidate();
      utils.attendance.sessionWithRecords.invalidate();
      utils.attendance.listHalls.invalidate();
      toast.success("تم حذف الجلسة بنجاح");
      setDeleteId(null);
    },
    onError: (e) => toast.error("تعذر الحذف", { description: e.message }),
  });

  const totals = useMemo(() => {
    let present = 0;
    let absent = 0;
    let total = 0;
    for (const s of sessions) {
      present += s.presentCount;
      absent += s.absentCount;
      total += s.totalCount;
    }
    const rate = total > 0 ? Math.round((present / total) * 100) : 0;
    return { present, absent, total, rate };
  }, [sessions]);

  const resetFilters = () => {
    setDateFilter("");
    setHallFilter("all");
    setFromDate("");
    setToDate("");
  };

  const handleExportSessions = () => {
    exportSessionsToExcel(
      `سجل_جلسات_الغياب`,
      sessions.map((s) => ({
        date: s.sessionDate,
        time: s.recordedTime,
        hall: s.hallName,
        present: s.presentCount,
        absent: s.absentCount,
        total: s.totalCount,
        savedBy: s.savedBy,
      }))
    );
  };

  const handleExportCSV = () => {
    exportToCSV(
      "سجل_جلسات_الغياب",
      sessions.map((s) => ({
        "التاريخ": s.sessionDate,
        "الوقت": s.recordedTime || "-",
        "القاعة": s.hallName,
        "الحاضرون": s.presentCount,
        "الغائبون": s.absentCount,
        "الإجمالي": s.totalCount,
        "المسجل": s.savedBy || "-",
      }))
    );
  };

  const handleExportDetail = () => {
    if (!detailQ.data) return;
    const { session, records } = detailQ.data;
    exportAttendanceToExcel(
      `تفاصيل_غياب_${session.hallCode}_${session.sessionDate}`,
      records.map((r) => ({
        date: session.sessionDate,
        hall: session.hallName,
        studentNumber: r.studentNumber,
        studentName: r.fullName,
        status: r.status,
        recordedTime: session.recordedTime,
        notes: r.notes,
      }))
    );
  };

  return (
    <div className="min-h-screen bg-dot-grid flex flex-col">
      <Navbar title="سجل الغياب الإلكتروني" />

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-6 space-y-5">
        <CrownHeader
          title="سجل الغياب اليومي"
          subtitle="استعراض وإدارة جميع جلسات الحضور والغياب المسجلة"
          compact
        />

        {/* Filters */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                تاريخ محدد
              </label>
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                القاعة
              </label>
              <Select value={hallFilter} onValueChange={setHallFilter}>
                <SelectTrigger className="rounded-xl text-sm font-semibold">
                  <SelectValue placeholder="كل القاعات" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="all">كل القاعات (28)</SelectItem>
                  {halls.map((h) => (
                    <SelectItem key={h.id} value={String(h.id)}>
                      {h.name} ({toArabicNumerals(h.studentCount)} طالب)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                من تاريخ
              </label>
              <Input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                إلى تاريخ
              </label>
              <Input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <button
              type="button"
              onClick={resetFilters}
              className="flex items-center gap-1 text-slate-500 hover:text-slate-900 hover:underline"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة ضبط الفلاتر</span>
            </button>
            <div className="flex flex-wrap gap-1.5">
              <Button
                size="sm"
                variant="outline"
                onClick={handleExportSessions}
                className="rounded-xl text-xs h-8"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 ml-1" />
                تصدير Excel
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleExportCSV}
                className="rounded-xl text-xs h-8"
              >
                <FileDown className="w-3.5 h-3.5 ml-1" />
                CSV
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={printPage}
                className="rounded-xl text-xs h-8"
              >
                <Printer className="w-3.5 h-3.5 ml-1" />
                طباعة
              </Button>
            </div>
          </div>
        </section>

        {/* Totals */}
        <section className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
          <div className="p-3 rounded-2xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800">
            <span className="text-slate-500 block">الجلسات</span>
            <span className="text-xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(sessions.length)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800">
            <span className="text-slate-500 block">إجمالي المرصود</span>
            <span className="text-xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(totals.total)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900">
            <span className="text-emerald-800 dark:text-emerald-300 block">حاضر</span>
            <span className="text-xl font-black text-emerald-700 dark:text-emerald-300">
              {toArabicNumerals(totals.present)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/80 dark:border-rose-900">
            <span className="text-rose-800 dark:text-rose-300 block">غائب</span>
            <span className="text-xl font-black text-rose-700 dark:text-rose-300">
              {toArabicNumerals(totals.absent)}
            </span>
          </div>
          <div className="col-span-2 sm:col-span-1 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900">
            <span className="text-amber-800 dark:text-amber-300 block">نسبة الحضور</span>
            <span className="text-xl font-black text-amber-800 dark:text-amber-300">
              %{toArabicNumerals(totals.rate)}
            </span>
          </div>
        </section>

        {/* Sessions list */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-slate-900 dark:text-slate-100">
              الجلسات المسجلة ({toArabicNumerals(sessions.length)})
            </h2>
            <Link href="/" className="text-xs font-bold text-amber-700 hover:underline flex items-center gap-1">
              <PlusCircle className="w-3.5 h-3.5" />
              <span>تسجيل جلسة جديدة</span>
            </Link>
          </div>

          {sessionsQ.isLoading ? (
            <div className="text-center py-12 text-sm text-slate-400">
              جارٍ تحميل السجلات...
            </div>
          ) : sessions.length === 0 ? (
            <div className="text-center py-12 text-sm text-slate-400 space-y-2">
              <p>لا توجد جلسات مسجلة تطابق هذه الفلاتر</p>
              <Link href="/">
                <Button size="sm" className="rounded-xl text-xs">
                  الانتقال لتسجيل حضور اليوم
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {sessions.map((s) => {
                const rate =
                  s.totalCount > 0
                    ? Math.round((s.presentCount / s.totalCount) * 100)
                    : 0;
                return (
                  <div
                    key={s.id}
                    className="p-3.5 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-amber-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start sm:items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800 flex flex-col items-center justify-center shrink-0">
                        <Calendar className="w-4 h-4 text-amber-700 dark:text-amber-300" />
                        <span className="text-[10px] font-black text-amber-800 dark:text-amber-200">
                          {toArabicNumerals(s.sessionDate.slice(-2))}
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-base text-slate-900 dark:text-slate-100">
                          {s.hallName}
                        </p>
                        <p className="text-xs text-slate-400">
                          {formatArabicDateDisplay(s.sessionDate)} •{" "}
                          {formatFullArabicDate(
                            new Date(s.sessionDate + "T12:00:00")
                          )}{" "}
                          {s.recordedTime ? `• ${s.recordedTime}` : ""}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-end gap-2 text-xs">
                      <span className="px-2.5 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                        {toArabicNumerals(s.presentCount)} حاضر
                      </span>
                      <span className="px-2.5 py-1 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 font-bold">
                        {toArabicNumerals(s.absentCount)} غائب
                      </span>
                      <span className="px-2.5 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 font-black">
                        %{toArabicNumerals(rate)}
                      </span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setDetailSessionId(s.id)}
                        className="rounded-xl text-xs h-8"
                      >
                        <Eye className="w-3.5 h-3.5 ml-1" />
                        التفاصيل
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setDeleteId(s.id)}
                        className="rounded-xl text-xs h-8 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                        title="حذف الجلسة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      {/* Details Dialog */}
      <Dialog
        open={Boolean(detailSessionId)}
        onOpenChange={(o) => !o && setDetailSessionId(null)}
      >
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-right">
              تفاصيل غياب {detailQ.data?.session.hallName} —{" "}
              {detailQ.data?.session
                ? formatArabicDateDisplay(detailQ.data.session.sessionDate)
                : ""}
            </DialogTitle>
          </DialogHeader>

          {detailQ.data && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                  حاضر: {toArabicNumerals(detailQ.data.session.presentCount)}
                </span>
                <span className="px-2.5 py-1 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 font-bold">
                  غائب: {toArabicNumerals(detailQ.data.session.absentCount)}
                </span>
                <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold">
                  الإجمالي: {toArabicNumerals(detailQ.data.session.totalCount)}
                </span>
                {detailQ.data.session.recordedTime && (
                  <span className="px-2.5 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 font-bold">
                    وقت التسجيل: {detailQ.data.session.recordedTime}
                  </span>
                )}
                {detailQ.data.session.savedBy && (
                  <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                    المسجل: {detailQ.data.session.savedBy}
                  </span>
                )}
              </div>

              <div className="flex justify-between items-center pt-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleExportDetail}
                  className="rounded-xl text-xs"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 ml-1" />
                  تصدير تفاصيل الطلاب إلى Excel
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={printPage}
                  className="rounded-xl text-xs"
                >
                  <Printer className="w-3.5 h-3.5 ml-1" />
                  طباعة
                </Button>
              </div>

              <div className="space-y-1.5 pt-1">
                {detailQ.data.records.map((r) => {
                  const isAbsent = r.status === "absent";
                  return (
                    <div
                      key={r.recordId}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-sm ${
                        isAbsent
                          ? "bg-rose-50/70 border-rose-200 dark:bg-rose-950/25 dark:border-rose-900"
                          : "bg-white border-slate-200/90 dark:bg-slate-900 dark:border-slate-800"
                      }`}
                    >
                      <div className="text-right">
                        <span className="font-bold text-slate-900 dark:text-slate-100 block">
                          {r.fullName}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {r.studentNumber}
                          {r.seatNumber
                            ? ` • المقعد ${toArabicNumerals(r.seatNumber)}`
                            : ""}
                          {r.notes ? ` • ${r.notes}` : ""}
                        </span>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1 ${
                          isAbsent
                            ? "bg-rose-600 text-white"
                            : "bg-emerald-600 text-white"
                        }`}
                      >
                        {isAbsent ? (
                          <>
                            <XCircle className="w-3.5 h-3.5" />
                            <span>غائب</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>حاضر</span>
                          </>
                        )}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog
        open={Boolean(deleteId)}
        onOpenChange={(o) => !o && setDeleteId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="text-right">
            <AlertDialogTitle>تأكيد حذف الجلسة</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذه الجلسة؟ سيتم حذف جميع سجلات الطلاب التابعة لها. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row justify-between sm:justify-between">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ sessionId: deleteId })}
              className="bg-rose-600 hover:bg-rose-700"
            >
              نعم، احذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
