import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import CrownHeader from "@/components/CrownHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Settings as SettingsIcon,
  Globe,
  FileSpreadsheet,
  Download,
  BookOpen,
  Sparkles,
  ExternalLink,
  CheckCircle2,
  Layers,
  HelpCircle,
} from "lucide-react";

export default function Settings() {
  const settingsQ = trpc.attendance.settings.useQuery();
  const raw = settingsQ.data ?? {};

  const [title, setTitle] = useState("سجل الغياب الإلكتروني");
  const [subtitle, setSubtitle] = useState("رصد الحضور والغياب اليومي للقاعات الـ 28");
  const [org, setOrg] = useState("سجل الغياب الإلكتروني - Dior");

  useEffect(() => {
    if (raw.system_title) setTitle(raw.system_title);
    if (raw.system_subtitle) setSubtitle(raw.system_subtitle);
    if (raw.organization_name) setOrg(raw.organization_name);
  }, [raw.system_title, raw.system_subtitle, raw.organization_name]);

  const utils = trpc.useUtils();
  const up = trpc.attendance.updateSetting.useMutation({
    onSuccess: () => {
      utils.attendance.settings.invalidate();
      toast.success("تم حفظ الإعدادات");
    },
    onError: (e) => toast.error("تعذر الحفظ", { description: e.message }),
  });

  const handleSave = () => {
    up.mutate({ key: "system_title", value: title });
    up.mutate({ key: "system_subtitle", value: subtitle });
    up.mutate({ key: "organization_name", value: org });
  };

  return (
    <div className="min-h-screen bg-dot-grid flex flex-col">
      <Navbar title="سجل الغياب الإلكتروني" />

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-6 space-y-5">
        <CrownHeader
          title="الإعدادات والدليل"
          subtitle="تخصيص هوية النظام ودليل بناء نموذج مماثل عبر Google Sites و Google Sheets"
          compact
        />

        {/* Identity customization */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-amber-600" />
            <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
              هوية النظام والنصوص
            </h3>
          </div>
          <div className="space-y-3 text-sm text-right">
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                اسم النظام الرئيسي
              </label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="rounded-xl font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                النص الفرعي (الوصف)
              </label>
              <Input
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                اسم الجهة / العلامة (يظهر في الرأس مثل Dior)
              </label>
              <Input
                value={org}
                onChange={(e) => setOrg(e.target.value)}
                className="rounded-xl"
              />
            </div>
            <div className="pt-1 flex justify-end">
              <Button onClick={handleSave} className="rounded-xl bg-slate-900 dark:bg-amber-400 dark:text-slate-950 font-bold">
                حفظ التعديلات
              </Button>
            </div>
          </div>
        </section>

        {/* Excel Template download banner */}
        <section className="p-5 rounded-3xl bg-gradient-to-l from-emerald-700 via-teal-700 to-emerald-900 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-right">
            <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-7 h-7 text-emerald-200" />
            </div>
            <div>
              <h4 className="font-black text-base sm:text-lg">
                قالب Excel جاهز لسجل غياب الطلاب
              </h4>
              <p className="text-xs text-emerald-100">
                ملف إكسل مصمم للـ 28 قاعة بمعادلات إحصائية تلقائية وتنسيق عربي احترافي — يمكنك فتحه في Excel أو رفعه مباشرة إلى Google Sheets
              </p>
            </div>
          </div>
          <a
            href="/سجل_الغياب_اليومي_للقاعات_28.xlsx"
            download
            className="shrink-0 inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-white text-emerald-900 font-black text-sm shadow hover:bg-emerald-50 transition"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل القالب (XLSX)</span>
          </a>
        </section>

        {/* Google Sites / Google Sheets Tutorial */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-600" />
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                كيف تبني مثل هذا النظام على Google Sites و Google Sheets
              </h3>
              <p className="text-xs text-slate-400">
                النظام الذي رأيته في الصورة مبني عبر Google Sites كواجهة مرتبطة بـ Google Apps Script و Google Sheets
              </p>
            </div>
          </div>

          <div className="space-y-3 text-sm text-slate-700 dark:text-slate-200 text-right">
            {/* Step 1 */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-1">
              <div className="flex items-center gap-2 font-black text-slate-900 dark:text-slate-100">
                <span className="w-6 h-6 rounded-lg bg-amber-600 text-white text-xs font-black flex items-center justify-center">1</span>
                <span>الخطوة الأولى — إنشاء ملف Google Sheets لقاعدة البيانات</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 pr-8">
                افتح <strong>sheets.google.com</strong> وأنشئ جدولاً به 3 أوراق عمل: ورقة «الطلاب» (رقم الطالب، الاسم، القاعة، المقعد)، ورقة «القاعات» (رمز القاعة، السعة) — القاعات: 101-109 بالدور الأول، 201-210 بالدور الثاني، 301-309 بالدور الثالث — وورقة «سجل الغياب» للأعمدة: التاريخ، الوقت، القاعة، رقم الطالب، الاسم، الحالة (حاضر/غائب)، المشرف.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-1">
              <div className="flex items-center gap-2 font-black text-slate-900 dark:text-slate-100">
                <span className="w-6 h-6 rounded-lg bg-amber-600 text-white text-xs font-black flex items-center justify-center">2</span>
                <span>الخطوة الثانية — بناء واجهة التطبيق عبر Google Apps Script</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 pr-8">
                من قائمة ملف الشيت اختر <strong>ملحقات &gt; Apps Script</strong>. اكتب واجهة HTML/CSS/JS مخصصة للهواتف (مثل تصميم Dior هذا: التاريخ والوقت وأزرار حفظ البيانات وتغييب الكل وقائمة القاعات)، ثم استخدم دوال doGet و doPost لقراءة قوائم الطلاب وحفظ حالات الغياب في الشيت مباشرة.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-1">
              <div className="flex items-center gap-2 font-black text-slate-900 dark:text-slate-100">
                <span className="w-6 h-6 rounded-lg bg-amber-600 text-white text-xs font-black flex items-center justify-center">3</span>
                <span>الخطوة الثالثة — نشر السكربت كتطبيق ويب (Web App)</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 pr-8">
                في Apps Script اضغط <strong>نشر &gt; نشر جديد &gt; تطبيق ويب</strong>، واضبط إذن الوصول حسب حاجتك (متاح لأي شخص لديه الرابط، أو لمستخدمي النطاق الأكاديمي فقط)، وانسخ رابط التطبيق المنشور.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-1">
              <div className="flex items-center gap-2 font-black text-slate-900 dark:text-slate-100">
                <span className="w-6 h-6 rounded-lg bg-amber-600 text-white text-xs font-black flex items-center justify-center">4</span>
                <span>الخطوة الرابعة — التضمين في Google Sites مثل الصورة</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 pr-8">
                افتح <strong>sites.google.com</strong>، أنشئ موقعاً جديداً سمّه «سجل الغياب الإلكتروني»، اضغط <strong>تضمين (Embed) &gt; بواسطة رابط</strong> والصق رابط تطبيق الويب، ثم اضغط <strong>نشر</strong> لتحصل على رابط موقع جاهز للاستخدام من الجوال مثل الرابط الذي رأيته في المتصفح.
              </p>
            </div>

            {/* Option B: Forms */}
            <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 space-y-1">
              <div className="flex items-center gap-2 font-black text-amber-950 dark:text-amber-200">
                <HelpCircle className="w-4 h-4 text-amber-700" />
                <span>طريقة بديلة أسرع بدون برمجة: Google Forms</span>
              </div>
              <p className="text-xs text-amber-900/80 dark:text-amber-300 pr-6">
                أنشئ <strong>Google Form</strong> بالحقول: التاريخ، رقم القاعة (قائمة)، اسم الطالب، الحالة (حاضر/غائب)، واربطه بـ Google Sheet ثم ضمّن النموذج داخل Google Sites — أسهل في الإنشاء وأقل تخصيصاً للشكل.
              </p>
            </div>
          </div>
        </section>

        {/* System info */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs text-xs text-slate-500 space-y-1.5 text-right">
          <p className="font-bold text-slate-700 dark:text-slate-300">
            سجل الغياب الإلكتروني • الإصدار 1.0
          </p>
          <p>
            تطبيق ويب احترافي متجاوب لرصد الحضور والغياب اليومي للطلاب، مستوحى من نظام سجل الغياب الإلكتروني (Dior)، مع دعم 28 قاعة (101-109، 201-210، 301-309) و700 طالب وقاعدة بيانات MySQL وتقارير وإحصائيات وتصدير Excel/CSV.
          </p>
        </section>
      </main>
    </div>
  );
}
