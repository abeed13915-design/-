import { trpc } from "@/lib/trpc";
import { useState } from "react";
import Navbar from "@/components/Navbar";
import CrownHeader from "@/components/CrownHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  toArabicNumerals,
  formatArabicDateDisplay,
  formatFullArabicDate,
} from "@/lib/dateUtils";
import { exportSessionsToExcel, exportToCSV, printPage } from "@/lib/exportUtils";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
  CartesianGrid,
  Legend,
} from "recharts";
import {
  Building2,
  Users,
  CheckCircle2,
  XCircle,
  Percent,
  FileSpreadsheet,
  Printer,
  CalendarCheck,
  TrendingUp,
} from "lucide-react";

export default function Stats() {
  const [dateFilter, setDateFilter] = useState<string>("");
  const [hallFilter, setHallFilter] = useState<string>("all");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");

  const hallsQ = trpc.attendance.listHalls.useQuery();
  const halls = hallsQ.data ?? [];

  const statsQ = trpc.attendance.stats.useQuery({
    date: dateFilter || undefined,
    hallId: hallFilter !== "all" ? Number(hallFilter) : undefined,
    fromDate: fromDate || undefined,
    toDate: toDate || undefined,
  });
  const s = statsQ.data;

  const hallChartData = (s?.hallBreakdown ?? [])
    .slice(0, 14)
    .map((h) => ({
      name: `${h.code}`,
      present: h.present,
      absent: h.absent,
      rate: h.rate,
    }));

  const trendData = (s?.dailyTrend ?? []).map((d) => ({
    date: formatArabicDateDisplay(d.sessionDate),
    rawDate: d.sessionDate,
    rate: d.rate,
    present: d.present,
    absent: d.absent,
  }));

  const handleExportBreakdown = () => {
    if (!s) return;
    exportSessionsToExcel(
      "تقرير_حضور_القاعات",
      s.hallBreakdown.map((h) => ({
        date: dateFilter || "كل الفترات",
        hall: h.name,
        present: h.present,
        absent: h.absent,
        total: h.total,
        rate: h.rate,
        savedBy: "-",
      }))
    );
  };

  const handleExportCSV = () => {
    if (!s) return;
    exportToCSV(
      "تقرير_حضور_القاعات",
      s.hallBreakdown.map((h) => ({
        "القاعة": h.name,
        "الرمز": h.code,
        "السعة": h.capacity,
        "الحاضرون": h.present,
        "الغائبون": h.absent,
        "الإجمالي": h.total,
        "نسبة الحضور": `${h.rate}%`,
      }))
    );
  };

  return (
    <div className="min-h-screen bg-dot-grid flex flex-col">
      <Navbar title="سجل الغياب الإلكتروني" />

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-6 space-y-5">
        <CrownHeader
          title="التقارير والإحصائيات"
          subtitle="تحليل الحضور والغياب حسب القاعة واليوم مع مؤشرات الأداء"
          compact
        />

        {/* Filters */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                تاريخ محدد
              </label>
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                القاعة
              </label>
              <Select value={hallFilter} onValueChange={setHallFilter}>
                <SelectTrigger className="rounded-xl text-sm font-semibold">
                  <SelectValue placeholder="كل القاعات" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="all">كل القاعات</SelectItem>
                  {halls.map((h) => (
                    <SelectItem key={h.id} value={String(h.id)}>
                      {h.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                من تاريخ
              </label>
              <Input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                إلى تاريخ
              </label>
              <Input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="rounded-xl text-sm"
              />
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <span className="text-slate-400">
              {dateFilter
                ? `تصفية حسب: ${formatFullArabicDate(new Date(dateFilter + "T12:00:00"))}`
                : "جميع الفترات الزمنية"}
            </span>
            <div className="flex gap-1.5">
              <Button
                size="sm"
                variant="outline"
                onClick={handleExportBreakdown}
                className="rounded-xl text-xs h-8"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 ml-1" />
                تصدير Excel
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={printPage}
                className="rounded-xl text-xs h-8"
              >
                <Printer className="w-3.5 h-3.5 ml-1" />
                طباعة
              </Button>
            </div>
          </div>
        </section>

        {/* KPI Cards */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          <div className="p-4 rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 text-center">
            <Building2 className="w-5 h-5 mx-auto text-amber-600 mb-1" />
            <span className="text-[11px] text-slate-500 block">عدد القاعات</span>
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(s?.totalHalls ?? 28)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 text-center">
            <Users className="w-5 h-5 mx-auto text-amber-600 mb-1" />
            <span className="text-[11px] text-slate-500 block">إجمالي الطلاب</span>
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(s?.totalStudents ?? 700)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 text-center">
            <CalendarCheck className="w-5 h-5 mx-auto text-indigo-600 mb-1" />
            <span className="text-[11px] text-slate-500 block">الجلسات المسجلة</span>
            <span className="text-2xl font-black text-indigo-700 dark:text-indigo-300">
              {toArabicNumerals(s?.recordedSessions ?? 0)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900 text-center">
            <CheckCircle2 className="w-5 h-5 mx-auto text-emerald-600 mb-1" />
            <span className="text-[11px] text-emerald-800 dark:text-emerald-300 block">
              الحاضرون
            </span>
            <span className="text-2xl font-black text-emerald-700 dark:text-emerald-300">
              {toArabicNumerals(s?.presentCount ?? 0)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/80 dark:border-rose-900 text-center">
            <XCircle className="w-5 h-5 mx-auto text-rose-600 mb-1" />
            <span className="text-[11px] text-rose-800 dark:text-rose-300 block">الغائبون</span>
            <span className="text-2xl font-black text-rose-700 dark:text-rose-300">
              {toArabicNumerals(s?.absentCount ?? 0)}
            </span>
          </div>
          <div className="col-span-2 sm:col-span-1 p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900 text-center">
            <Percent className="w-5 h-5 mx-auto text-amber-700 mb-1" />
            <span className="text-[11px] text-amber-800 dark:text-amber-300 block">
              نسبة الحضور
            </span>
            <span className="text-2xl font-black text-amber-800 dark:text-amber-300">
              %{toArabicNumerals(s?.attendanceRate ?? 0)}
            </span>
          </div>
        </section>

        {/* Charts row */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Hall comparison bar chart */}
          <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                مقارنة القاعات (حاضر / غائب)
              </h3>
              <span className="text-xs text-slate-400">أول 14 قاعة</span>
            </div>
            {hallChartData.length > 0 ? (
              <div className="h-72" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={hallChartData}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(v, name) => [
                        toArabicNumerals(Number(v)),
                        name === "present" ? "حاضر" : "غائب",
                      ]}
                      labelFormatter={(l) => `القاعة ${toArabicNumerals(String(l))}`}
                    />
                    <Legend
                      formatter={(val) => (val === "present" ? "حاضر" : "غائب")}
                    />
                    <Bar dataKey="present" fill="#059669" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="absent" fill="#e11d48" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-72 flex items-center justify-center text-xs text-slate-400">
                لا توجد بيانات كافية لعرض المخطط
              </div>
            )}
          </div>

          {/* Daily trend area chart */}
          <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-amber-600" />
                <span>اتجاه نسبة الحضور اليومية</span>
              </h3>
              <span className="text-xs text-slate-400">آخر 14 يوماً</span>
            </div>
            {trendData.length > 0 ? (
              <div className="h-72" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="rateGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#c9942f" stopOpacity={0.7} />
                        <stop offset="95%" stopColor="#c9942f" stopOpacity={0.05} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                    <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                    <YAxis domain={[0, 100]} unit="%" tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(v) => [`%${toArabicNumerals(Number(v))}`, "نسبة الحضور"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="rate"
                      stroke="#c9942f"
                      strokeWidth={2.5}
                      fill="url(#rateGrad)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-72 flex items-center justify-center text-xs text-slate-400">
                سجل جلسات حضور لعرض اتجاه النسبة اليومية
              </div>
            )}
          </div>
        </section>

        {/* Hall breakdown table */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
              تفصيل القاعات الـ 28
            </h3>
            <span className="text-xs text-slate-400">
              مرتبة حسب رقم القاعة
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold">
                  <th className="py-2.5 px-3">القاعة</th>
                  <th className="py-2.5 px-3">السعة</th>
                  <th className="py-2.5 px-3">الجلسات</th>
                  <th className="py-2.5 px-3">حاضر</th>
                  <th className="py-2.5 px-3">غائب</th>
                  <th className="py-2.5 px-3">الإجمالي</th>
                  <th className="py-2.5 px-3">نسبة الحضور</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {(s?.hallBreakdown ?? []).map((h) => (
                  <tr
                    key={h.hallId}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition"
                  >
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">
                      {h.name}
                    </td>
                    <td className="py-2.5 px-3">{toArabicNumerals(h.capacity)}</td>
                    <td className="py-2.5 px-3">{toArabicNumerals(h.sessions)}</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-700">
                      {toArabicNumerals(h.present)}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-rose-700">
                      {toArabicNumerals(h.absent)}
                    </td>
                    <td className="py-2.5 px-3">{toArabicNumerals(h.total)}</td>
                    <td className="py-2.5 px-3 font-black text-amber-700">
                      {h.total > 0 ? `%${toArabicNumerals(h.rate)}` : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
