import { trpc } from "@/lib/trpc";
import { useMemo, useState, useEffect } from "react";
import { toast } from "sonner";
import CrownHeader from "@/components/CrownHeader";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Clock,
  Calendar as CalendarIcon,
  Save,
  UserX,
  Users,
  CheckCircle2,
  XCircle,
  Search,
  ChevronLeft,
  ChevronRight,
  Info,
  RotateCcw,
  Sparkles,
  FileText,
  Printer,
  FileSpreadsheet,
} from "lucide-react";
import {
  formatArabicDateDisplay,
  formatArabicTime,
  formatFullArabicDate,
  toArabicNumerals,
  toISODateString,
} from "@/lib/dateUtils";
import { exportAttendanceToExcel, printPage } from "@/lib/exportUtils";
import { Link } from "wouter";

type AttendanceMap = Record<number, "present" | "absent">;
type NotesMap = Record<number, string>;

export default function Home() {
  const [selectedDate, setSelectedDate] = useState<string>(() =>
    toISODateString(new Date())
  );
  const [selectedHallId, setSelectedHallId] = useState<number | null>(null);
  const [attendance, setAttendance] = useState<AttendanceMap>({});
  const [notes, setNotes] = useState<NotesMap>({});
  const [currentTime, setCurrentTime] = useState<string>(() =>
    formatArabicTime(new Date())
  );
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "present" | "absent">("all");
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [infoOpen, setInfoOpen] = useState(false);
  const [noteDialogStudent, setNoteDialogStudent] = useState<{
    id: number;
    name: string;
  } | null>(null);
  const [noteDraft, setNoteDraft] = useState("");

  useEffect(() => {
    const t = setInterval(() => setCurrentTime(formatArabicTime(new Date())), 1000);
    return () => clearInterval(t);
  }, []);

  const hallsQ = trpc.attendance.listHalls.useQuery();
  const halls = hallsQ.data ?? [];

  const effectiveHallId = selectedHallId ?? (halls[0]?.id ?? null);
  const selectedHall = halls.find((h) => h.id === effectiveHallId);

  const studentsQ = trpc.attendance.hallStudents.useQuery(
    { hallId: effectiveHallId ?? -1 },
    { enabled: effectiveHallId !== null }
  );
  const students = studentsQ.data ?? [];

  const sessionQ = trpc.attendance.sessionWithRecords.useQuery(
    {
      hallId: effectiveHallId ?? -1,
      sessionDate: selectedDate,
    },
    { enabled: effectiveHallId !== null }
  );

  useEffect(() => {
    if (!students || students.length === 0) return;
    const sessionData = sessionQ.data;
    const nextAtt: AttendanceMap = {};
    const nextNotes: NotesMap = {};

    if (sessionData && sessionData.records && sessionData.records.length > 0) {
      const recMap = new Map(sessionData.records.map((r) => [r.studentId, r]));
      for (const s of students) {
        const r = recMap.get(s.id);
        nextAtt[s.id] = r ? r.status : "present";
        if (r?.notes) nextNotes[s.id] = r.notes;
      }
      setLastSaved(sessionData.session.recordedTime || sessionData.session.sessionDate);
    } else {
      for (const s of students) {
        nextAtt[s.id] = "present";
      }
      setLastSaved(null);
    }
    setAttendance(nextAtt);
    setNotes(nextNotes);
  }, [sessionQ.data, students]);

  const utils = trpc.useUtils();
  const saveMutation = trpc.attendance.save.useMutation({
    onSuccess: (data) => {
      utils.attendance.sessionWithRecords.invalidate();
      utils.attendance.listSessions.invalidate();
      utils.attendance.stats.invalidate();
      utils.attendance.listHalls.invalidate();
      const savedTime = formatArabicTime(new Date());
      setLastSaved(savedTime);
      toast.success("تم حفظ بيانات الغياب بنجاح", {
        description: `القاعة ${selectedHall?.code ?? ""}: ${toArabicNumerals(
          data.present
        )} حاضر • ${toArabicNumerals(data.absent)} غائب • الوقت ${savedTime}`,
      });
    },
    onError: (err) => {
      toast.error("تعذر الحفظ", { description: err.message });
    },
  });

  const markAllAbsent = () => {
    if (students.length === 0) return;
    const next: AttendanceMap = {};
    for (const s of students) next[s.id] = "absent";
    setAttendance(next);
    toast.info("تم تعيين جميع الطلاب غائبين", {
      description: "يمكنك الآن تعديل حالات الطلاب الحاضرين قبل الحفظ",
    });
  };

  const markAllPresent = () => {
    if (students.length === 0) return;
    const next: AttendanceMap = {};
    for (const s of students) next[s.id] = "present";
    setAttendance(next);
    toast.info("تم تعيين جميع الطلاب حاضرين");
  };

  const toggleStudent = (id: number) => {
    setAttendance((prev) => ({
      ...prev,
      [id]: prev[id] === "absent" ? "present" : "absent",
    }));
  };

  const handleSave = () => {
    if (!effectiveHallId || students.length === 0) return;
    const records = students.map((s) => ({
      studentId: s.id,
      status: (attendance[s.id] ?? "present") as "present" | "absent",
      notes: notes[s.id],
    }));
    saveMutation.mutate({
      hallId: effectiveHallId,
      sessionDate: selectedDate,
      recordedTime: currentTime,
      records,
    });
  };

  const currentIndex = halls.findIndex((h) => h.id === effectiveHallId);
  const prevHall = currentIndex > 0 ? halls[currentIndex - 1] : null;
  const nextHall = currentIndex >= 0 && currentIndex < halls.length - 1 ? halls[currentIndex + 1] : null;

  const absentCount = useMemo(
    () => students.filter((s) => attendance[s.id] === "absent").length,
    [students, attendance]
  );
  const presentCount = students.length - absentCount;
  const attendanceRate =
    students.length > 0 ? Math.round((presentCount / students.length) * 100) : 0;

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const att = attendance[s.id] ?? "present";
      if (filter === "present" && att !== "present") return false;
      if (filter === "absent" && att !== "absent") return false;
      if (search.trim()) {
        const q = search.trim();
        return (
          s.fullName.includes(q) ||
          s.studentNumber.includes(q) ||
          String(s.seatNumber ?? "").includes(q)
        );
      }
      return true;
    });
  }, [students, attendance, filter, search]);

  const handleExport = () => {
    if (!selectedHall) return;
    exportAttendanceToExcel(`غياب_القاعة_${selectedHall.code}_${selectedDate}`, [
      ...students.map((s) => ({
        date: selectedDate,
        hall: selectedHall.name,
        studentNumber: s.studentNumber,
        studentName: s.fullName,
        status: attendance[s.id] ?? "present",
        recordedTime: lastSaved,
        notes: notes[s.id] ?? null,
      })),
    ]);
  };

  return (
    <div className="min-h-screen bg-dot-grid flex flex-col">
      <Navbar title="سجل الغياب الإلكتروني" />

      <main className="flex-1 max-w-xl sm:max-w-2xl mx-auto w-full px-3.5 sm:px-4 py-4 sm:py-6 space-y-4">
        {/* Luxury Crown Header - exact screenshot layout */}
        <section className="bg-white/70 dark:bg-slate-900/70 backdrop-blur rounded-3xl p-4 sm:p-5 border border-amber-200/50 dark:border-slate-800 shadow-2xs">
          <CrownHeader
            title="سجل الغياب"
            subtitle="رصد الحضور والغياب اليومي للقاعات الـ 28"
            brand="Dior"
          />
        </section>

        {/* Time and Date cards - matching screenshot card style */}
        <section
          aria-label="الوقت والتاريخ"
          className="bg-white/80 dark:bg-slate-900/80 backdrop-blur rounded-3xl p-3.5 sm:p-4 border border-blue-100/70 dark:border-slate-800 shadow-2xs space-y-2.5"
        >
          {/* Time Card */}
          <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
              {currentTime}
            </span>
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 flex items-center justify-center text-amber-600 dark:text-amber-300">
              <Clock className="w-6 h-6 stroke-[2.2]" />
            </div>
          </div>

          {/* Date Card */}
          <Popover>
            <PopoverTrigger asChild>
              <button
                type="button"
                className="w-full flex items-center justify-between px-4 sm:px-6 py-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:border-amber-300 transition text-right group"
              >
                <div className="text-right">
                  <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-wider">
                    {formatArabicDateDisplay(selectedDate)}
                  </span>
                  <span className="block text-[11px] text-slate-400 group-hover:text-amber-700 transition">
                    انقر لتغيير التاريخ • {formatFullArabicDate(new Date(selectedDate + "T12:00:00"))}
                  </span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 flex items-center justify-center text-amber-600 dark:text-amber-300">
                  <CalendarIcon className="w-6 h-6 stroke-[2.2]" />
                </div>
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-3" align="start">
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                اختر تاريخ الرصد
              </label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="text-sm font-semibold"
              />
              <div className="flex justify-between items-center mt-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedDate(toISODateString(new Date()))}
                  className="text-amber-700 dark:text-amber-400 font-bold hover:underline"
                >
                  اليوم الحالي
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedDate("2026-11-06")}
                  className="text-slate-500 hover:underline"
                >
                  تاريخ النموذج (2026/11/06)
                </button>
              </div>
            </PopoverContent>
          </Popover>
        </section>

        {/* Action Buttons Row - Save & Mark All Absent, matching screenshot */}
        <section aria-label="أزرار الإجراءات">
          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={handleSave}
              disabled={saveMutation.isPending || students.length === 0}
              className="flex items-center justify-center gap-2.5 px-4 py-4 rounded-2xl bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-white font-black text-lg sm:text-xl shadow-md hover:from-blue-900 hover:to-indigo-900 active:scale-[0.99] transition disabled:opacity-50"
            >
              <Save className="w-6 h-6 stroke-[2.4]" />
              <span>{saveMutation.isPending ? "جارٍ الحفظ..." : "حفظ البيانات"}</span>
            </button>

            <button
              type="button"
              onClick={markAllAbsent}
              disabled={students.length === 0}
              className="flex items-center justify-center gap-2 px-4 py-4 rounded-2xl border-2 border-blue-950 dark:border-amber-400 bg-white/90 dark:bg-slate-900 text-blue-950 dark:text-amber-300 font-black text-lg sm:text-xl shadow-xs hover:bg-blue-50 dark:hover:bg-slate-800 active:scale-[0.99] transition disabled:opacity-50"
            >
              <UserX className="w-6 h-6 stroke-[2.4]" />
              <span>تغييب الكل</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-xs px-1 pt-1.5 text-slate-500">
            <button
              type="button"
              onClick={markAllPresent}
              className="text-emerald-700 dark:text-emerald-400 font-bold hover:underline"
            >
              تحضير الكل
            </button>
            <button
              type="button"
              onClick={() => {
                if (students.length === 0) return;
                const next: AttendanceMap = {};
                for (const s of students) next[s.id] = "present";
                setAttendance(next);
                setNotes({});
              }}
              className="flex items-center gap-1 hover:text-slate-800 hover:underline"
            >
              <RotateCcw className="w-3 h-3" />
              <span>إعادة ضبط القائمة</span>
            </button>
          </div>
        </section>

        {/* Hall selector row - dropdown "القاعة: 101 (25 طالب)" + "غياب الطلاب" badge */}
        <section
          aria-label="اختيار القاعة"
          className="bg-white/80 dark:bg-slate-900/80 backdrop-blur rounded-3xl p-3 sm:p-3.5 border border-blue-100/70 dark:border-slate-800 shadow-2xs space-y-2.5"
        >
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              disabled={!prevHall}
              onClick={() => prevHall && setSelectedHallId(prevHall.id)}
              aria-label="القاعة السابقة"
              className="rounded-2xl shrink-0 h-12 w-12"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>

            <div className="flex-1 min-w-0">
              <Select
                value={effectiveHallId ? String(effectiveHallId) : undefined}
                onValueChange={(v) => setSelectedHallId(Number(v))}
              >
                <SelectTrigger className="w-full h-12 rounded-2xl text-sm sm:text-base font-black bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700 shadow-xs px-2.5 sm:px-4 justify-between gap-1">
                  <span className="truncate flex items-center justify-center gap-1.5 flex-1 min-w-0">
                    {selectedHall
                      ? (
                        <>
                          <span className="text-slate-900 dark:text-slate-100 whitespace-nowrap">
                            القاعة: {selectedHall.code}
                          </span>
                          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                            ({toArabicNumerals(selectedHall.studentCount)} طالب)
                          </span>
                        </>
                      )
                      : "اختر القاعة..."}
                  </span>
                </SelectTrigger>
                <SelectContent className="max-h-80">
                  {halls.map((h) => (
                    <SelectItem
                      key={h.id}
                      value={String(h.id)}
                      className="text-sm font-bold text-right"
                    >
                      القاعة: {h.code} — {toArabicNumerals(h.studentCount)} طالباً
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              type="button"
              variant="outline"
              size="icon"
              disabled={!nextHall}
              onClick={() => nextHall && setSelectedHallId(nextHall.id)}
              aria-label="القاعة التالية"
              className="rounded-2xl shrink-0 h-12 w-12"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>

            <button
              type="button"
              onClick={() => setInfoOpen(true)}
              className="h-12 px-3.5 sm:px-4 rounded-2xl bg-blue-950 text-white font-bold text-sm sm:text-base flex items-center gap-1.5 shadow-xs hover:bg-blue-900 transition shrink-0"
              title="معلومات القاعة والجلسة"
            >
              <Info className="w-4 h-4 text-amber-300" />
              <Users className="w-4.5 h-4.5" />
              <span className="hidden xs:inline">غياب الطلاب</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>
              {selectedHall?.floor ? `${selectedHall.floor} • ` : ""}السعة:{" "}
              {toArabicNumerals(selectedHall?.capacity ?? 25)} طالباً
            </span>
            {lastSaved && (
              <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
                ✓ آخر حفظ: {lastSaved}
              </span>
            )}
          </div>
        </section>

        {/* Real-time Stats summary card */}
        <section
          aria-label="ملخص الحضور"
          className="bg-white/80 dark:bg-slate-900/80 backdrop-blur rounded-3xl p-3.5 sm:p-4 border border-blue-100/70 dark:border-slate-800 shadow-2xs"
        >
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="p-2 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/60">
              <span className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 block">
                الحاضرون
              </span>
              <span className="text-xl sm:text-2xl font-black text-emerald-700 dark:text-emerald-300">
                {toArabicNumerals(presentCount)}
              </span>
            </div>
            <div className="p-2 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/80 dark:border-rose-800/60">
              <span className="text-[11px] font-semibold text-rose-800 dark:text-rose-300 block">
                الغائبون
              </span>
              <span className="text-xl sm:text-2xl font-black text-rose-700 dark:text-rose-300">
                {toArabicNumerals(absentCount)}
              </span>
            </div>
            <div className="p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60">
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block">
                الإجمالي
              </span>
              <span className="text-xl sm:text-2xl font-black text-slate-800 dark:text-slate-100">
                {toArabicNumerals(students.length)}
              </span>
            </div>
            <div className="p-2 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/60">
              <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-300 block">
                نسبة الحضور
              </span>
              <span className="text-xl sm:text-2xl font-black text-amber-800 dark:text-amber-300">
                {toArabicNumerals(attendanceRate)}٪
              </span>
            </div>
          </div>

          <div className="mt-3">
            <div className="h-2 w-full rounded-full bg-rose-100 dark:bg-rose-950/60 overflow-hidden flex">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-300"
                style={{ width: `${attendanceRate}%` }}
              />
            </div>
          </div>
        </section>

        {/* Student attendance list */}
        <section
          aria-label="قائمة الطلاب"
          className="bg-white/80 dark:bg-slate-900/80 backdrop-blur rounded-3xl p-3.5 sm:p-4 border border-blue-100/70 dark:border-slate-800 shadow-2xs space-y-3"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              <span>طلاب القاعة</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600">
                {toArabicNumerals(filteredStudents.length)} / {toArabicNumerals(students.length)}
              </span>
            </h2>
            <div className="flex items-center gap-1">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleExport}
                className="rounded-xl text-xs h-8"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 ml-1" />
                تصدير Excel
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={printPage}
                className="rounded-xl text-xs h-8"
              >
                <Printer className="w-3.5 h-3.5 ml-1" />
                طباعة
              </Button>
            </div>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث باسم الطالب أو الرقم الجامعي..."
              className="pr-9 rounded-2xl h-11 text-sm bg-white dark:bg-slate-900"
            />
          </div>

          <div className="flex gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setFilter("all")}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${
                filter === "all"
                  ? "bg-slate-900 text-white dark:bg-amber-400 dark:text-slate-950"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              }`}
            >
              الكل ({toArabicNumerals(students.length)})
            </button>
            <button
              type="button"
              onClick={() => setFilter("present")}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${
                filter === "present"
                  ? "bg-emerald-700 text-white"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              }`}
            >
              الحاضرون ({toArabicNumerals(presentCount)})
            </button>
            <button
              type="button"
              onClick={() => setFilter("absent")}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${
                filter === "absent"
                  ? "bg-rose-700 text-white"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              }`}
            >
              الغائبون ({toArabicNumerals(absentCount)})
            </button>
          </div>

          <div className="space-y-2 pt-1">
            {studentsQ.isLoading ? (
              <div className="text-center py-10 text-sm text-slate-400">
                جارٍ تحميل بيانات الطلاب...
              </div>
            ) : filteredStudents.length === 0 ? (
              <div className="text-center py-10 text-sm text-slate-400">
                لا توجد نتائج مطابقة للبحث
              </div>
            ) : (
              filteredStudents.map((s) => {
                const isAbsent = attendance[s.id] === "absent";
                const hasNote = Boolean(notes[s.id]);
                return (
                  <div
                    key={s.id}
                    className={`flex items-center justify-between gap-3 p-3 rounded-2xl border transition ${
                      isAbsent
                        ? "bg-rose-50/70 dark:bg-rose-950/25 border-rose-200 dark:border-rose-900"
                        : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <span className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-black flex items-center justify-center shrink-0">
                        {toArabicNumerals(s.seatNumber ?? "-")}
                      </span>
                      <div className="min-w-0 text-right flex-1">
                        <p className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 truncate">
                          {s.fullName}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate">
                          {s.studentNumber}
                          {hasNote && (
                            <span className="mr-2 text-amber-700 dark:text-amber-400 font-semibold">
                              • ملاحظة: {notes[s.id]}
                            </span>
                          )}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setNoteDialogStudent({ id: s.id, name: s.fullName });
                          setNoteDraft(notes[s.id] ?? "");
                        }}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition text-xs ${
                          hasNote
                            ? "bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300"
                            : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
                        }`}
                        title="إضافة ملاحظة"
                      >
                        <FileText className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => toggleStudent(s.id)}
                        className={`min-w-22 px-3 py-2 rounded-xl font-black text-sm flex items-center justify-center gap-1.5 transition shadow-xs active:scale-95 ${
                          isAbsent
                            ? "bg-rose-600 text-white hover:bg-rose-700"
                            : "bg-emerald-600 text-white hover:bg-emerald-700"
                        }`}
                      >
                        {isAbsent ? (
                          <>
                            <XCircle className="w-4 h-4" />
                            <span>غائب</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>حاضر</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* Quick Links */}
        <section className="grid grid-cols-2 gap-2 text-center">
          <Link
            href="/records"
            className="p-3.5 rounded-2xl bg-white/80 dark:bg-slate-900/80 backdrop-blur border border-blue-100/70 dark:border-slate-800 shadow-2xs hover:border-amber-300 transition block"
          >
            <span className="text-xs font-bold text-amber-700 dark:text-amber-400 block">
              استعراض
            </span>
            <span className="text-sm font-black text-slate-900 dark:text-slate-100">
              سجل الغياب اليومي
            </span>
          </Link>
          <Link
            href="/stats"
            className="p-3.5 rounded-2xl bg-white/80 dark:bg-slate-900/80 backdrop-blur border border-blue-100/70 dark:border-slate-800 shadow-2xs hover:border-amber-300 transition block"
          >
            <span className="text-xs font-bold text-amber-700 dark:text-amber-400 block">
              تحليل
            </span>
            <span className="text-sm font-black text-slate-900 dark:text-slate-100">
              التقارير والإحصائيات
            </span>
          </Link>
        </section>
      </main>

      <Dialog open={infoOpen} onOpenChange={setInfoOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-right">
              تفاصيل {selectedHall?.name ?? "القاعة"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2.5 text-sm py-2 text-right">
            <div className="flex justify-between py-1.5 border-b">
              <span className="font-bold">{selectedHall?.code ? toArabicNumerals(selectedHall.code) : "-"}</span>
              <span className="text-slate-500">رقم القاعة:</span>
            </div>
            <div className="flex justify-between py-1.5 border-b">
              <span className="font-bold">{toArabicNumerals(students.length)} طالباً</span>
              <span className="text-slate-500">عدد الطلاب المسجلين:</span>
            </div>
            <div className="flex justify-between py-1.5 border-b">
              <span className="font-bold">{toArabicNumerals(selectedHall?.capacity ?? 25)} طالباً</span>
              <span className="text-slate-500">سعة القاعة:</span>
            </div>
            <div className="flex justify-between py-1.5 border-b">
              <span className="font-bold">{selectedHall?.floor || "غير محدد"}</span>
              <span className="text-slate-500">الدور / الموقع:</span>
            </div>
            <div className="flex justify-between py-1.5 border-b">
              <span className="font-bold">{lastSaved ? `✓ تم الرصد (${lastSaved})` : "لم يتم الحفظ بعد"}</span>
              <span className="text-slate-500">حالة رصد اليوم:</span>
            </div>
          </div>
          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setInfoOpen(false);
                handleExport();
              }}
              className="text-xs"
            >
              تصدير بيانات هذه القاعة
            </Button>
            <Button type="button" onClick={() => setInfoOpen(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={Boolean(noteDialogStudent)}
        onOpenChange={(o) => !o && setNoteDialogStudent(null)}
      >
        <DialogContent className="max-w-md">
          <DialogHeader className="text-right">
            <DialogTitle className="text-right">
              ملاحظة على الطالب: {noteDialogStudent?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <Textarea
              value={noteDraft}
              onChange={(e) => setNoteDraft(e.target.value)}
              placeholder="اكتب ملاحظة هنا (مثل: مستأذن، تقرير طبي، وصل متأخراً...)"
              className="min-h-24 text-sm"
              maxLength={255}
            />
          </div>
          <DialogFooter className="flex-row justify-between sm:justify-between">
            {noteDialogStudent && notes[noteDialogStudent.id] && (
              <Button
                type="button"
                variant="destructive"
                className="text-xs"
                onClick={() => {
                  if (!noteDialogStudent) return;
                  setNotes((prev) => {
                    const n = { ...prev };
                    delete n[noteDialogStudent.id];
                    return n;
                  });
                  setNoteDialogStudent(null);
                }}
              >
                حذف الملاحظة
              </Button>
            )}
            <Button
              type="button"
              onClick={() => {
                if (noteDialogStudent) {
                  setNotes((prev) => ({
                    ...prev,
                    [noteDialogStudent.id]: noteDraft.trim(),
                  }));
                }
                setNoteDialogStudent(null);
              }}
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <footer className="mt-8 border-t border-slate-200/80 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-4 text-center text-xs text-slate-400">
        <p className="flex items-center justify-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>سجل الغياب الإلكتروني — رصد الحضور والغياب اليومي لـ 28 قاعة دراسية</span>
        </p>
      </footer>
    </div>
  );
}
