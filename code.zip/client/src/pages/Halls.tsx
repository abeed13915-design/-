import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import Navbar from "@/components/Navbar";
import CrownHeader from "@/components/CrownHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toArabicNumerals } from "@/lib/dateUtils";
import { exportToCSV, printPage } from "@/lib/exportUtils";
import {
  Building2,
  Users,
  Search,
  Plus,
  Pencil,
  Trash2,
  FileSpreadsheet,
  Printer,
  ChevronLeft,
} from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

interface StudentForm {
  studentNumber: string;
  fullName: string;
  hallId: number;
  seatNumber?: number;
  phone?: string;
  email?: string;
  notes?: string;
}

export default function Halls() {
  const hallsQ = trpc.attendance.listHalls.useQuery();
  const halls = hallsQ.data ?? [];

  const [selectedHallId, setSelectedHallId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [editStudent, setEditStudent] = useState<{
    id: number;
    studentNumber: string;
    fullName: string;
    hallId: number;
    seatNumber?: number | null;
    phone?: string | null;
    email?: string | null;
    notes?: string | null;
  } | null>(null);
  const [deleteId, setDeleteId] = useState<{ id: number; name: string } | null>(null);

  const [form, setForm] = useState<StudentForm>({
    studentNumber: "",
    fullName: "",
    hallId: 0,
  });

  const effectiveHallId = showAll ? null : (selectedHallId ?? (halls[0]?.id ?? null));

  const studentsQ = trpc.attendance.searchStudents.useQuery({
    search: search || undefined,
    hallId: effectiveHallId ?? undefined,
    limit: 200,
  });
  const students = studentsQ.data ?? [];

  const utils = trpc.useUtils();

  const addMutation = trpc.attendance.addStudent.useMutation({
    onSuccess: () => {
      utils.attendance.searchStudents.invalidate();
      utils.attendance.hallStudents.invalidate();
      utils.attendance.listHalls.invalidate();
      utils.attendance.stats.invalidate();
      toast.success("تمت إضافة الطالب بنجاح");
      setAddOpen(false);
      setForm({ studentNumber: "", fullName: "", hallId: 0 });
    },
    onError: (e) => toast.error("تعذر الإضافة", { description: e.message }),
  });

  const updateMutation = trpc.attendance.updateStudent.useMutation({
    onSuccess: () => {
      utils.attendance.searchStudents.invalidate();
      utils.attendance.hallStudents.invalidate();
      utils.attendance.stats.invalidate();
      toast.success("تم تحديث بيانات الطالب");
      setEditStudent(null);
    },
    onError: (e) => toast.error("تعذر التحديث", { description: e.message }),
  });

  const deleteMutation = trpc.attendance.deleteStudent.useMutation({
    onSuccess: () => {
      utils.attendance.searchStudents.invalidate();
      utils.attendance.hallStudents.invalidate();
      utils.attendance.listHalls.invalidate();
      utils.attendance.stats.invalidate();
      toast.success("تم حذف الطالب");
      setDeleteId(null);
    },
    onError: (e) => toast.error("تعذر الحذف", { description: e.message }),
  });

  const hallMap = useMemo(() => new Map(halls.map((h) => [h.id, h])), [halls]);

  const totalEnrolled = useMemo(
    () => halls.reduce((a, b) => a + (b.studentCount ?? 0), 0),
    [halls]
  );

  const handleExportRoster = () => {
    const rows = students.map((s, i) => ({
      "م": i + 1,
      "القاعة": hallMap.get(s.hallId)?.name ?? "-",
      "الرقم الجامعي": s.studentNumber,
      "اسم الطالب": s.fullName,
      "المقعد": s.seatNumber ? toArabicNumerals(s.seatNumber) : "-",
      "الهاتف": s.phone || "-",
      "البريد": s.email || "-",
      "ملاحظات": s.notes || "-",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [
      { wch: 6 },
      { wch: 16 },
      { wch: 18 },
      { wch: 28 },
      { wch: 10 },
      { wch: 16 },
      { wch: 26 },
      { wch: 20 },
    ];
    const wb = XLSX.utils.book_new();
    wb.Workbook = { Views: [{ RTL: true }] };
    XLSX.utils.book_append_sheet(wb, ws, "قائمة الطلاب");
    const suffix = effectiveHallId
      ? `_${hallMap.get(effectiveHallId)?.code ?? ""}`
      : "_الكل";
    XLSX.writeFile(wb, `قائمة_الطلاب${suffix}.xlsx`);
  };

  const handleExportCSV = () => {
    exportToCSV(
      "قائمة_الطلاب",
      students.map((s) => ({
        "القاعة": hallMap.get(s.hallId)?.name ?? "-",
        "الرقم الجامعي": s.studentNumber,
        "اسم الطالب": s.fullName,
        "المقعد": s.seatNumber ?? "-",
        "الهاتف": s.phone || "-",
        "البريد": s.email || "-",
      }))
    );
  };

  return (
    <div className="min-h-screen bg-dot-grid flex flex-col">
      <Navbar title="سجل الغياب الإلكتروني" />

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-6 space-y-5">
        <CrownHeader
          title="إدارة القاعات والطلاب"
          subtitle="استعراض 28 قاعة دراسية وقوائم الطلاب المسجلين بكل قاعة"
          compact
        />

        <section className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-center text-xs">
          <div className="p-4 rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800">
            <Building2 className="w-5 h-5 mx-auto text-amber-600 mb-1" />
            <span className="text-slate-500 block">القاعات</span>
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(halls.length)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800">
            <Users className="w-5 h-5 mx-auto text-amber-600 mb-1" />
            <span className="text-slate-500 block">الطلاب المسجلون</span>
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
              {toArabicNumerals(totalEnrolled)}
            </span>
          </div>
          <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900">
            <span className="text-amber-800 dark:text-amber-300 block">طلاب القاعة المحددة</span>
            <span className="text-2xl font-black text-amber-800 dark:text-amber-300">
              {toArabicNumerals(effectiveHallId ? (hallMap.get(effectiveHallId)?.studentCount ?? 0) : totalEnrolled)}
            </span>
          </div>
        </section>

        {/* Hall chips */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">
              اختر قاعة لعرض طلابها
            </h3>
            <button
              type="button"
              onClick={() => {
                setShowAll(!showAll);
                setSelectedHallId(null);
              }}
              className="text-xs text-amber-700 hover:underline font-bold"
            >
              {showAll ? "عرض حسب القاعة" : "عرض كل القاعات (دليل شامل)"}
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto">
            {halls.map((h) => (
              <button
                key={h.id}
                type="button"
                onClick={() => {
                  setSelectedHallId(h.id);
                  setShowAll(false);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  effectiveHallId === h.id
                    ? "bg-amber-700 text-white"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                }`}
              >
                {h.name} ({toArabicNumerals(h.studentCount)})
              </button>
            ))}
          </div>
        </section>

        {/* Students list */}
        <section className="bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-2xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                {effectiveHallId
                  ? `طلاب ${hallMap.get(effectiveHallId)?.name ?? "القاعة"}`
                  : "جميع الطلاب المسجلين"}
              </h3>
              <p className="text-xs text-slate-400">
                {toArabicNumerals(students.length)} طالباً
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <Button
                size="sm"
                onClick={() => {
                  setForm({
                    studentNumber: "",
                    fullName: "",
                    hallId: effectiveHallId ?? (halls[0]?.id ?? 0),
                  });
                  setAddOpen(true);
                }}
                className="rounded-xl text-xs bg-slate-900 dark:bg-amber-400 dark:text-slate-950"
              >
                <Plus className="w-3.5 h-3.5 ml-1" />
                إضافة طالب
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleExportRoster}
                className="rounded-xl text-xs"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 ml-1" />
                Excel
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleExportCSV}
                className="rounded-xl text-xs"
              >
                CSV
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={printPage}
                className="rounded-xl text-xs"
              >
                <Printer className="w-3.5 h-3.5 ml-1" />
                طباعة
              </Button>
            </div>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالاسم أو الرقم الجامعي..."
              className="pr-9 rounded-2xl h-11 text-sm bg-white dark:bg-slate-900"
            />
          </div>

          <div className="space-y-1.5">
            {studentsQ.isLoading ? (
              <div className="text-center py-12 text-sm text-slate-400">
                جارٍ تحميل البيانات...
              </div>
            ) : students.length === 0 ? (
              <div className="text-center py-12 text-sm text-slate-400">
                لا يوجد طلاب يطابقون البحث
              </div>
            ) : (
              students.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center justify-between p-3 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-amber-300 transition text-sm gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs font-black flex items-center justify-center shrink-0">
                      {toArabicNumerals(s.seatNumber ?? "-")}
                    </span>
                    <div className="min-w-0 text-right">
                      <span className="font-bold text-slate-900 dark:text-slate-100 block truncate">
                        {s.fullName}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {s.studentNumber} • {hallMap.get(s.hallId)?.name ?? "-"}
                        {s.phone ? ` • ${s.phone}` : ""}
                        {s.notes ? ` • ${s.notes}` : ""}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditStudent(s)}
                      className="rounded-xl text-xs h-8"
                    >
                      <Pencil className="w-3.5 h-3.5 ml-1" />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setDeleteId({ id: s.id, name: s.fullName })}
                      className="rounded-xl text-xs h-8 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>
      </main>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader className="text-right">
            <DialogTitle>إضافة طالب جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2 text-sm text-right">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                اسم الطالب الكامل *
              </label>
              <Input
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="مثال: خالد محمد العتيبي"
                className="rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                الرقم الجامعي / الأكاديمي *
              </label>
              <Input
                value={form.studentNumber}
                onChange={(e) =>
                  setForm({ ...form, studentNumber: e.target.value })
                }
                placeholder="مثال: STD-101-26"
                className="rounded-xl font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                القاعة *
              </label>
              <Select
                value={String(form.hallId || halls[0]?.id || "")}
                onValueChange={(v) => setForm({ ...form, hallId: Number(v) })}
              >
                <SelectTrigger className="rounded-xl text-xs font-semibold">
                  <SelectValue placeholder="اختر القاعة" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {halls.map((h) => (
                    <SelectItem key={h.id} value={String(h.id)}>
                      {h.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  رقم المقعد
                </label>
                <Input
                  type="number"
                  value={form.seatNumber ?? ""}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      seatNumber: e.target.value ? Number(e.target.value) : undefined,
                    })
                  }
                  className="rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  رقم الهاتف
                </label>
                <Input
                  value={form.phone ?? ""}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="rounded-xl text-xs font-mono"
                  placeholder="05XXXXXXXX"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                البريد الإلكتروني
              </label>
              <Input
                value={form.email ?? ""}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="rounded-xl text-xs"
                placeholder="student@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                ملاحظات
              </label>
              <Input
                value={form.notes ?? ""}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="rounded-xl text-xs"
              />
            </div>
          </div>
          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => setAddOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              type="button"
              disabled={
                !form.fullName.trim() || !form.studentNumber.trim() || addMutation.isPending
              }
              onClick={() => addMutation.mutate({ ...form, hallId: form.hallId || halls[0]?.id })}
            >
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(editStudent)} onOpenChange={(o) => !o && setEditStudent(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader className="text-right">
            <DialogTitle>تعديل بيانات الطالب</DialogTitle>
          </DialogHeader>
          {editStudent && (
            <div className="space-y-3 py-2 text-sm text-right">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  اسم الطالب الكامل
                </label>
                <Input
                  value={editStudent.fullName}
                  onChange={(e) =>
                    setEditStudent({ ...editStudent, fullName: e.target.value })
                  }
                  className="rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  الرقم الجامعي
                </label>
                <Input
                  value={editStudent.studentNumber}
                  onChange={(e) =>
                    setEditStudent({ ...editStudent, studentNumber: e.target.value })
                  }
                  className="rounded-xl font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  القاعة
                </label>
                <Select
                  value={String(editStudent.hallId)}
                  onValueChange={(v) =>
                    setEditStudent({ ...editStudent, hallId: Number(v) })
                  }
                >
                  <SelectTrigger className="rounded-xl text-xs font-semibold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {halls.map((h) => (
                      <SelectItem key={h.id} value={String(h.id)}>
                        {h.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    رقم المقعد
                  </label>
                  <Input
                    type="number"
                    value={editStudent.seatNumber ?? ""}
                    onChange={(e) =>
                      setEditStudent({
                        ...editStudent,
                        seatNumber: e.target.value ? Number(e.target.value) : null,
                      })
                    }
                    className="rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    رقم الهاتف
                  </label>
                  <Input
                    value={editStudent.phone ?? ""}
                    onChange={(e) =>
                      setEditStudent({ ...editStudent, phone: e.target.value })
                    }
                    className="rounded-xl text-xs font-mono"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  البريد الإلكتروني
                </label>
                <Input
                  value={editStudent.email ?? ""}
                  onChange={(e) =>
                    setEditStudent({ ...editStudent, email: e.target.value })
                  }
                  className="rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  ملاحظات
                </label>
                <Input
                  value={editStudent.notes ?? ""}
                  onChange={(e) =>
                    setEditStudent({ ...editStudent, notes: e.target.value })
                  }
                  className="rounded-xl text-xs"
                />
              </div>
            </div>
          )}
          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditStudent(null)}
            >
              إلغاء
            </Button>
            <Button
              type="button"
              onClick={() =>
                editStudent &&
                updateMutation.mutate({
                  id: editStudent.id,
                  fullName: editStudent.fullName,
                  studentNumber: editStudent.studentNumber,
                  hallId: editStudent.hallId,
                  seatNumber: editStudent.seatNumber,
                  phone: editStudent.phone || null,
                  email: editStudent.email || null,
                  notes: editStudent.notes || null,
                })
              }
            >
              حفظ التعديلات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteId)}
        onOpenChange={(o) => !o && setDeleteId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="text-right">
            <AlertDialogTitle>تأكيد حذف الطالب</AlertDialogTitle>
            <AlertDialogDescription>
              هل تريد حذف الطالب «{deleteId?.name}»؟ سيتم إخفاؤه من القائمة ولن يؤثر ذلك على السجلات السابقة.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row justify-between sm:justify-between">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId.id })}
              className="bg-rose-600 hover:bg-rose-700"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
