import * as XLSX from "xlsx";

export function exportAttendanceToExcel(
  filename: string,
  records: Array<{
    date: string;
    hall: string;
    studentNumber: string;
    studentName: string;
    status: string;
    recordedTime?: string | null;
    notes?: string | null;
  }>
) {
  const arabicRows = records.map((r, i) => ({
    "م": i + 1,
    "التاريخ": r.date,
    "القاعة": r.hall,
    "الرقم الجامعي": r.studentNumber,
    "اسم الطالب": r.studentName,
    "حالة الحضور": r.status === "present" ? "حاضر" : "غائب",
    "وقت التسجيل": r.recordedTime || "-",
    "ملاحظات": r.notes || "-",
  }));

  const ws = XLSX.utils.json_to_sheet(arabicRows);
  // Column widths
  ws["!cols"] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 16 },
    { wch: 18 },
    { wch: 28 },
    { wch: 14 },
    { wch: 16 },
    { wch: 24 },
  ];

  const wb = XLSX.utils.book_new();
  wb.Workbook = { Views: [{ RTL: true }] };
  XLSX.utils.book_append_sheet(wb, ws, "سجل الغياب");
  XLSX.writeFile(wb, filename.endsWith(".xlsx") ? filename : `${filename}.xlsx`);
}

export function exportToCSV(filename: string, rows: Array<Record<string, unknown>>) {
  if (rows.length === 0) return;
  const headers = Object.keys(rows[0]);
  const csv = [
    "\uFEFF" + headers.join(","),
    ...rows.map((r) => headers.map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(",")),
  ].join("\r\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportSessionsToExcel(
  filename: string,
  sessions: Array<{
    date: string;
    time?: string | null;
    hall: string;
    present: number;
    absent: number;
    total: number;
    rate?: number;
    savedBy?: string | null;
  }>
) {
  const rows = sessions.map((s, i) => ({
    "م": i + 1,
    "التاريخ": s.date,
    "الوقت": s.time || "-",
    "القاعة": s.hall,
    "الحاضرون": s.present,
    "الغائبون": s.absent,
    "الإجمالي": s.total,
    "نسبة الحضور": s.total > 0 ? `${((s.present / s.total) * 100).toFixed(1)}%` : "0%",
    "المسجل": s.savedBy || "-",
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 12 },
    { wch: 16 },
    { wch: 12 },
    { wch: 12 },
    { wch: 12 },
    { wch: 14 },
    { wch: 18 },
  ];
  const wb = XLSX.utils.book_new();
  wb.Workbook = { Views: [{ RTL: true }] };
  XLSX.utils.book_append_sheet(wb, ws, "ملخص الجلسات");
  XLSX.writeFile(wb, filename.endsWith(".xlsx") ? filename : `${filename}.xlsx`);
}

export function printPage() {
  window.print();
}
