const ARABIC_DAYS = [
  "الأحد",
  "الإثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
  "السبت",
];

const ARABIC_MONTHS = [
  "يناير",
  "فبراير",
  "مارس",
  "أبريل",
  "مايو",
  "يونيو",
  "يوليو",
  "أغسطس",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];

export function toArabicNumerals(num: number | string): string {
  const digits = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];
  return String(num).replace(/[0-9]/g, (d) => digits[Number(d)]);
}

/** Formats date string "YYYY-MM-DD" to screenshot style "YYYY/MM/DD" with Arabic numerals */
export function formatArabicDateDisplay(isoDate: string): string {
  const [y, m, d] = isoDate.split("-");
  if (!y || !m || !d) return isoDate;
  return `${toArabicNumerals(y)}/${toArabicNumerals(m)}/${toArabicNumerals(d)}`;
}

/** Formats a Date object to "YYYY-MM-DD" string */
export function toISODateString(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/** Current time formatted in Arabic style: "8:13 م" */
export function formatArabicTime(date: Date, useArabicNumerals = true): string {
  let hours = date.getHours();
  const minutes = date.getMinutes();
  const isPM = hours >= 12;
  hours = hours % 12 || 12;
  const ampm = isPM ? "م" : "ص";
  const mm = String(minutes).padStart(2, "0");
  const base = `${hours}:${mm} ${ampm}`;
  return useArabicNumerals ? toArabicNumerals(base) : base;
}

/** Full human-readable Arabic date e.g. "الخميس ٦ نوفمبر ٢٠٢٦" */
export function formatFullArabicDate(date: Date): string {
  const dayName = ARABIC_DAYS[date.getDay()];
  const monthName = ARABIC_MONTHS[date.getMonth()];
  const d = toArabicNumerals(date.getDate());
  const y = toArabicNumerals(date.getFullYear());
  return `${dayName}، ${d} ${monthName} ${y}`;
}
