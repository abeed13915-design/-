interface CrownHeaderProps {
  title?: string;
  subtitle?: string;
  brand?: string;
  compact?: boolean;
}

export default function CrownHeader({
  title = "سجل الغياب",
  subtitle = "رصد الحضور والغياب اليومي للقاعات الـ 28",
  brand,
  compact = false,
}: CrownHeaderProps) {
  return (
    <div className="text-center select-none">
      {brand && (
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase mb-2 border border-amber-300/60 bg-amber-50/80 text-amber-900 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-700/60 shadow-xs">
          <span className="text-[10px] text-amber-600 dark:text-amber-300">★</span>
          <span>{brand}</span>
          <span className="text-[10px] text-amber-600 dark:text-amber-300">★</span>
        </div>
      )}

      {/* Gold Crown - matching the screenshot's 5-peak crown */}
      <div className="flex justify-center mb-1">
        <svg
          viewBox="0 0 100 80"
          className={`${compact ? "w-10 h-8" : "w-13 h-10.5"} drop-shadow-sm transition-transform hover:scale-105 duration-200`}
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="crownGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F7DF94" />
              <stop offset="50%" stopColor="#C9942F" />
              <stop offset="100%" stopColor="#8E6512" />
            </linearGradient>
            <linearGradient id="crownPearl" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#F7DF94" />
            </linearGradient>
          </defs>
          <rect x="8" y="66" width="84" height="9" rx="3" fill="url(#crownGold)" />
          <circle cx="20" cy="70.5" r="2.2" fill="url(#crownPearl)" />
          <circle cx="34" cy="70.5" r="2.2" fill="url(#crownPearl)" />
          <circle cx="50" cy="70.5" r="2.8" fill="url(#crownPearl)" />
          <circle cx="66" cy="70.5" r="2.2" fill="url(#crownPearl)" />
          <circle cx="80" cy="70.5" r="2.2" fill="url(#crownPearl)" />
          <path
            d="M 12 64 L 14 36 L 32 50 L 50 20 L 68 50 L 86 36 L 88 64 Z"
            fill="url(#crownGold)"
          />
          <circle cx="14" cy="32" r="3.6" fill="url(#crownPearl)" stroke="#8E6512" strokeWidth="0.8" />
          <circle cx="32" cy="46" r="3" fill="url(#crownPearl)" stroke="#8E6512" strokeWidth="0.8" />
          <circle cx="50" cy="16" r="4.6" fill="url(#crownPearl)" stroke="#8E6512" strokeWidth="0.9" />
          <circle cx="68" cy="46" r="3" fill="url(#crownPearl)" stroke="#8E6512" strokeWidth="0.8" />
          <circle cx="86" cy="32" r="3.6" fill="url(#crownPearl)" stroke="#8E6512" strokeWidth="0.8" />
        </svg>
      </div>

      <h1
        className={`font-black tracking-tight text-slate-900 dark:text-slate-50 ${
          compact ? "text-2xl" : "text-3xl sm:text-4xl"
        }`}
      >
        {title}
      </h1>

      {subtitle && (
        <p className="mt-1 text-sm sm:text-base text-slate-500 dark:text-slate-400 font-medium">
          {subtitle}
        </p>
      )}
    </div>
  );
}
