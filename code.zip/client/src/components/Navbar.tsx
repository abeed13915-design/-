import { useTheme } from "@/contexts/ThemeContext";
import {
  CalendarDays,
  FileSpreadsheet,
  BarChart3,
  Building2,
  Settings as SettingsIcon,
  Moon,
  Sun,
  Menu,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

interface NavbarProps {
  title?: string;
}

const NAV_ITEMS = [
  { href: "/", label: "الرئيسية", icon: CalendarDays },
  { href: "/records", label: "السجل اليومي", icon: FileSpreadsheet },
  { href: "/stats", label: "التقارير", icon: BarChart3 },
  { href: "/halls", label: "القاعات والطلاب", icon: Building2 },
  { href: "/settings", label: "الإعدادات", icon: SettingsIcon },
];

export default function Navbar({ title = "سجل الغياب الإلكتروني" }: NavbarProps) {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur border-b border-amber-100/80 dark:border-slate-800 shadow-2xs">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* Brand */}
        <Link
          href="/"
          className="flex items-center gap-2.5 group hover:opacity-95 transition"
        >
          <img src="/logo.svg" alt="logo" className="w-9 h-9" />
          <div className="text-right leading-tight">
            <span className="block text-base font-black tracking-tight text-slate-900 dark:text-slate-100">
              {title}
            </span>
            <span className="block text-[11px] font-semibold text-amber-700 dark:text-amber-400 -mt-0.5">
              رصد الحضور والغياب اليومي
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-semibold transition ${
                  active
                    ? "bg-slate-900 text-white dark:bg-amber-400 dark:text-slate-950 shadow-xs"
                    : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {toggleTheme && (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              aria-label="تبديل المظهر"
              className="rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {theme === "dark" ? (
                <Sun className="w-5 h-5 text-amber-400" />
              ) : (
                <Moon className="w-5 h-5 text-slate-700" />
              )}
            </Button>
          )}

          {/* Mobile hamburger */}
          <div className="md:hidden">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-xl"
                  aria-label="القائمة"
                >
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-0">
                <div className="p-5 border-b border-border flex items-center gap-2.5">
                  <img src="/logo.svg" alt="logo" className="w-9 h-9" />
                  <div className="text-right">
                    <p className="font-black text-sm text-slate-900 dark:text-slate-100">
                      {title}
                    </p>
                    <p className="text-[11px] text-amber-700 dark:text-amber-400">
                      القائمة الرئيسية
                    </p>
                  </div>
                </div>
                <nav className="p-3 space-y-1">
                  {NAV_ITEMS.map((item) => {
                    const Icon = item.icon;
                    const active = location === item.href;
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition ${
                          active
                            ? "bg-slate-900 text-white dark:bg-amber-400 dark:text-slate-950"
                            : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </Link>
                    );
                  })}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
