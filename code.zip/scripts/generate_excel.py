#!/usr/bin/env python3
"""Generate a professional Arabic student attendance Excel workbook.
Standards: one font, formulas not hardcoded, explicit widths, zero errors, RTL view, print layout.
"""
import json
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

wb = openpyxl.Workbook()
wb.remove(wb.active)

FONT_NAME = "Arial"
NAVY = "0F2D6B"
GOLD = "C9942F"
GOLD_LIGHT = "FBF2D9"
EMERALD = "059669"
ROSE = "E11D48"
GRAY_LIGHT = "F4F6F9"
GRAY_BORDER = "D1D5DB"
WHITE = "FFFFFF"

HALLS = (
    [str(x) for x in range(101, 110)]  # 101-109
    + [str(x) for x in range(201, 211)]  # 201-210
    + [str(x) for x in range(301, 310)]  # 301-309
)

with open("/home/ubuntu/absencereg/backups/attached-roster.json", encoding="utf-8") as f:
    ROSTER = json.load(f)

ACTUAL_COUNTS = {hall: sum(1 for student in ROSTER if student["hallCode"] == hall) for hall in HALLS}

def font(size=11, bold=False, color="000000", italic=False):
    return Font(name=FONT_NAME, size=size, bold=bold, color=color, italic=italic)

def fill(hex_color):
    return PatternFill(start_color=hex_color, end_color=hex_color, fill_type="solid")

def align(h="center", v="center", wrap=True):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

thin = Side(border_style="thin", color=GRAY_BORDER)
med = Side(border_style="medium", color=NAVY)
double_side = Side(border_style="double", color=NAVY)
box_border = Border(top=thin, left=thin, right=thin, bottom=thin)
header_border = Border(top=med, left=thin, right=thin, bottom=med)
total_border = Border(top=thin, left=thin, right=thin, bottom=double_side)

def set_row_height(ws, row, h):
    ws.row_dimensions[row].height = h

def set_col_widths(ws, widths):
    for col_idx, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = w

def style_cell(ws, cell, value, f, fl=None, al=None, bd=box_border, numfmt=None):
    c = ws[cell]
    c.value = value
    c.font = f
    if fl:
        c.fill = fl
    if al:
        c.alignment = al
    if bd:
        c.border = bd
    if numfmt:
        c.number_format = numfmt
    return c

def apply_rtl(ws):
    ws.sheet_view.rightToLeft = True
    ws.views.sheetView[0].showGridLines = True
    ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True

# =====================================================================
# SHEET 1: لوحة التحكم (Dashboard)
# =====================================================================
ws1 = wb.create_sheet(title="لوحة التحكم")
ws1.sheet_properties.tabColor = GOLD
apply_rtl(ws1)

ws1.merge_cells("A1:G1")
ws1.merge_cells("A2:G2")
style_cell(ws1, "A1", "سجل الغياب الإلكتروني", font(20, True, WHITE), fill(NAVY), align())
style_cell(ws1, "A2", "رصد الحضور والغياب اليومي للقاعات الـ 28 — ملخص لوحة التحكم", font(12, italic=True, color=WHITE), fill(NAVY), align())
set_row_height(ws1, 1, 34)
set_row_height(ws1, 2, 22)

kpis = [
    ("B5:B5", "B5", "عدد القاعات", font(10, color="555555"), GRAY_LIGHT),
    ("B6:B6", "B6", '=COUNTA(\'ملخص القاعات\'!A3:A30)', font(22, True, NAVY), WHITE),
    ("C5:C5", "C5", "إجمالي الطلاب", font(10, color="555555"), GRAY_LIGHT),
    ("C6:C6", "C6", '=SUM(\'ملخص القاعات\'!C3:C30)', font(22, True, NAVY), WHITE),
    ("D5:D5", "D5", "الحاضرون اليوم", font(10, color="555555"), GRAY_LIGHT),
    ("D6:D6", "D6", '=SUM(\'ملخص القاعات\'!D3:D30)', font(22, True, EMERALD), WHITE),
    ("E5:E5", "E5", "الغائبون اليوم", font(10, color="555555"), GRAY_LIGHT),
    ("E6:E6", "E6", '=SUM(\'ملخص القاعات\'!E3:E30)', font(22, True, ROSE), WHITE),
    ("F5:F5", "F5", "نسبة الحضور (من المرصود)", font(9, color="555555"), GRAY_LIGHT),
    ("F6:F6", "F6", '=IF((D6+E6)=0,0,D6/(D6+E6))', font(22, True, GOLD), WHITE),
]
for merge, cell, val, f_opt, fl_opt in kpis:
    style_cell(ws1, cell, val, f_opt, fill(fl_opt), align(), bd=box_border)
ws1["F6"].number_format = "0.0%"
set_row_height(ws1, 5, 20)
set_row_height(ws1, 6, 40)

set_row_height(ws1, 8, 14)
ws1.merge_cells("B9:F9")
style_cell(ws1, "B9", "موجز بيانات الرصد المباشر", font(13, True, WHITE), fill(GOLD), align())
set_row_height(ws1, 9, 28)
for cell, val in [("B10", "المؤشر"), ("C10", "القيمة"), ("D10", "المرجع"), ("E10", "حالة الأداء"), ("F10", "ملاحظة")]:
    style_cell(ws1, cell, val, font(10, True, WHITE), fill(NAVY), align(), header_border)
summary_rows = [
    ("متوسط نسبة الحضور", "=IF((D6+E6)=0,0,D6/(D6+E6))", "90% مستهدف", '=IF(C11>=0.9,"ممتاز","يحتاج متابعة")', "النسبة محسوبة تلقائياً"),
    ("عدد الغائبين", "=E6", "< 50 طالب", '=IF(C12<50,"ضمن المعدل","مرتفع")', "مجموع الغياب بكل القاعات"),
    ("عدد القاعات المرصودة", "=COUNTIF('ملخص القاعات'!H3:H30,\"مرصودة\")", "28 قاعة", '=IF(C13=28,"اكتمل الرصد","قيد الإنجاز")', "تحدّث عند رصد كل قاعة"),
    ("آخر تحديث", "=TODAY()", "-", "-", "تاريخ الملف"),
]
for i, r in enumerate(summary_rows, start=11):
    fl = GRAY_LIGHT if i % 2 == 0 else WHITE
    style_cell(ws1, f"B{i}", r[0], font(10, color="333333"), fill(fl), align("right", "center"))
    c = style_cell(ws1, f"C{i}", r[1], font(11, True, NAVY), fill(fl), align())
    if i == 11:
        c.number_format = "0.0%"
    elif i == 14:
        c.number_format = "yyyy/mm/dd"
    style_cell(ws1, f"D{i}", r[2], font(10, color="555555"), fill(fl), align())
    style_cell(ws1, f"E{i}", r[3], font(10, True, color="333333"), fill(fl), align())
    style_cell(ws1, f"F{i}", r[4], font(9, color="777777"), fill(fl), align("right", "center"))

set_col_widths(ws1, [4, 26, 18, 16, 18, 30])
ws1.freeze_panes = "A11"

# =====================================================================
# SHEET 2: رصد الغياب اليومي (Daily Tracking)
# =====================================================================
ws2 = wb.create_sheet(title="رصد الغياب اليومي")
ws2.sheet_properties.tabColor = NAVY
apply_rtl(ws2)

headers = ["م", "التاريخ", "الوقت", "رمز القاعة", "الرقم الأكاديمي", "اسم الطالب", "حالة الحضور", "ملاحظات", "المشرف"]
widths2 = [10, 14, 12, 14, 18, 30, 14, 28, 16]

ws2.merge_cells("A1:I1")
style_cell(ws2, "A1", "سجل رصد الحضور والغياب اليومي للطلاب — اختر الحالة من القائمة المنسدلة (حاضر / غائب)", font(12, True, WHITE), fill(NAVY), align())
set_row_height(ws2, 1, 26)

for c_idx, h in enumerate(headers, start=1):
    style_cell(ws2, f"{get_column_letter(c_idx)}2", h, font(10, True, WHITE), fill(GOLD), align(), header_border)
set_row_height(ws2, 2, 24)

SAMPLE_NAMES = [
    ("STD-101-01", "محمد العتيبي", "present", None),
    ("STD-101-02", "أحمد القحطاني", "present", None),
    ("STD-101-03", "عبدالله الحربي", "present", None),
    ("STD-101-04", "خالد الشهري", "absent", "عذر طبي"),
    ("STD-101-05", "عمر الزهراني", "present", None),
    ("STD-101-06", "فيصل الغامدي", "present", None),
    ("STD-101-07", "سلطان الدوسري", "present", None),
    ("STD-101-08", "سعود الشمري", "present", None),
    ("STD-101-09", "فهد العنزي", "absent", "مستأذن"),
    ("STD-101-10", "نايف المطيري", "present", None),
    ("STD-101-11", "عبدالعزيز السبيعي", "present", None),
    ("STD-101-12", "إبراهيم الرشيدي", "present", None),
    ("STD-101-13", "يوسف البلوي", "present", None),
    ("STD-101-14", "راشد الخالدي", "present", None),
    ("STD-101-15", "زياد القرني", "absent", None),
    ("STD-101-16", "طارق العمري", "present", None),
    ("STD-101-17", "ماجد الصاعدي", "present", None),
    ("STD-101-18", "وليد المالكي", "present", None),
    ("STD-101-19", "ريان السلمي", "present", None),
    ("STD-101-20", "سلمان الحارثي", "present", None),
    ("STD-101-21", "تركي الجهني", "present", None),
    ("STD-101-22", "حسام السفياني", "absent", None),
    ("STD-101-23", "حمزة الفيفي", "present", None),
    ("STD-101-24", "بسام السهلي", "present", None),
    ("STD-101-25", "مازن الجابري", "present", None),
    ("STD-102-01", "نواف المحمادي", "present", None),
    ("STD-102-02", "مشعل العوفي", "present", None),
    ("STD-102-03", "فارس الثقفي", "present", None),
    ("STD-102-04", "سارة الرويلي", "present", None),
    ("STD-102-05", "نورة العسيري", "absent", None),
    ("STD-102-06", "ريم الشهراني", "present", None),
    ("STD-102-07", "لينا الأنصاري", "present", None),
    ("STD-102-08", "جود الأحمدي", "present", None),
    ("STD-102-09", "مها الهاشمي", "present", None),
    ("STD-102-10", "فاطمة القرشي", "present", None),
    ("STD-102-11", "مريم الزبيدي", "absent", "تقرير طبي"),
    ("STD-102-12", "منيرة الصاعدي", "present", None),
    ("STD-102-13", "شهد المرواني", "present", None),
    ("STD-102-14", "غيداء الجهمي", "present", None),
    ("STD-102-15", "لمى النعماني", "present", None),
    ("STD-102-16", "هند البارقي", "present", None),
    ("STD-102-17", "رزان الداموك", "present", None),
    ("STD-102-18", "دانة الزيلعي", "present", None),
    ("STD-102-19", "أسيل البقمي", "absent", None),
    ("STD-102-20", "العنود الدلبحي", "present", None),
    ("STD-102-21", "الهنوف السلمي", "present", None),
    ("STD-102-22", "لجين العوفي", "present", None),
    ("STD-102-23", "يارا الأحمد", "present", None),
    ("STD-102-24", "ديما الحازمي", "present", None),
    ("STD-102-25", "حنين البدراني", "present", None),
]

row = 3
for idx, (sid, name, status, notes_val) in enumerate(SAMPLE_NAMES, start=1):
    hall_code = sid.split("-")[1]
    is_absent = status == "absent"
    st_color = ROSE if is_absent else EMERALD
    st_text = "غائب" if is_absent else "حاضر"
    st_fill = PatternFill(start_color="FFE4E9" if is_absent else "E7F7ED",
                          end_color="FFE4E9" if is_absent else "E7F7ED", fill_type="solid")
    fl = GRAY_LIGHT if row % 2 == 0 else WHITE

    style_cell(ws2, f"A{row}", idx, font(10), fill(fl), align())
    style_cell(ws2, f"B{row}", "2026-11-06", font(10), fill(fl), align(), numfmt="yyyy/mm/dd")
    style_cell(ws2, f"C{row}", "08:13", font(10), fill(fl), align())
    style_cell(ws2, f"D{row}", f"القاعة {hall_code}", font(10, bold=True), fill(fl), align())
    style_cell(ws2, f"E{row}", sid, font(10, color="555555"), fill(fl), align())
    style_cell(ws2, f"F{row}", name, font(10, bold=True), fill(fl), align("right", "center"))
    style_cell(ws2, f"G{row}", st_text, font(11, True, st_color), st_fill, align())
    style_cell(ws2, f"H{row}", notes_val or "", font(9, color="777777"), fill(fl), align("right", "center"))
    style_cell(ws2, f"I{row}", "المشرف", font(9, color="555555"), fill(fl), align())
    set_row_height(ws2, row, 20)
    row += 1

last_row = row - 1

style_cell(ws2, f"A{row}", "الإجمالي", font(10, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"F{row}", "=COUNTA(F3:F" + str(last_row) + ")", font(11, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"G{row}", "", font(11, True, EMERALD), fill(GOLD_LIGHT), align(), total_border)
ws2[f"G{row}"].value = f'="حاضر: " & COUNTIF(G3:G{last_row},"حاضر") & " | غائب: " & COUNTIF(G3:G{last_row},"غائب")'
style_cell(ws2, f"H{row}", "", font(11, True, GOLD), fill(GOLD_LIGHT), align(), total_border)
ws2[f"H{row}"].value = f'=IF(F{row}=0,0,COUNTIF(G3:G{last_row},"حاضر")/F{row})'
ws2[f"H{row}"].number_format = "0.0%"
style_cell(ws2, f"B{row}", "", font(10), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"C{row}", "", font(10), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"D{row}", "", font(10), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"E{row}", "", font(10), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws2, f"I{row}", "", font(10), fill(GOLD_LIGHT), align(), total_border)
set_row_height(ws2, row, 26)

dv = DataValidation(type="list", formula1='"حاضر,غائب"', allow_blank=True,
                    error="اختر حاضر أو غائب فقط", errorTitle="قيمة غير صحيحة",
                    prompt="اختر حالة الحضور", promptTitle="حالة الطالب")
ws2.add_data_validation(dv)
dv.add("G3:G500")

set_col_widths(ws2, widths2)
ws2.freeze_panes = "A3"

# =====================================================================
# SHEET 3: قوائم الطلاب (Student Directory - 28 halls: 101-109, 201-210, 301-309)
# =====================================================================
ws3 = wb.create_sheet(title="قوائم الطلاب")
ws3.sheet_properties.tabColor = "2563EB"
apply_rtl(ws3)

ws3.merge_cells("A1:H1")
style_cell(ws3, "A1", "دليل طلاب القاعات الدراسية — 889 طالباً مطابقاً للملف المرفق — السعة 39 طالباً لكل قاعة", font(12, True, WHITE), fill(NAVY), align())
set_row_height(ws3, 1, 26)

for ci, h in enumerate(["م", "القاعة", "المجموعة الأصلية", "المقعد", "الرقم الأكاديمي", "اسم الطالب", "الجوال", "البريد الإلكتروني"], start=1):
    style_cell(ws3, f"{get_column_letter(ci)}2", h, font(10, True, WHITE), fill(NAVY), align(), header_border)
set_row_height(ws3, 2, 24)

FIRST = ["محمد","أحمد","عبدالله","خالد","عمر","فيصل","سلطان","سعود","فهد","نايف","عبدالعزيز","إبراهيم","يوسف","راشد","زياد","طارق","ماجد","وليد","ريان","سلمان","تركي","حسام","حمزة","بسام","مازن","نواف","مشعل","فارس","سارة","نورة","ريم","لينا","جود","مها","فاطمة","مريم","منيرة","شهد","غيداء","لمى"]
LAST = ["العتيبي","القحطاني","الحربي","الشهري","الزهراني","الغامدي","الدوسري","الشمري","العنزي","المطيري","السبيعي","الرشيدي","البلوي","الخالدي","القرني","العمري","الصاعدي","المالكي","السلمي","الحارثي","الجهني","السفياني","الفيفي","السهلي","الجابري","المحمادي","العوفي","الثقفي","الرويلي","العسيري","الشهراني","الأنصاري"]

row3 = 3
for student in ROSTER:
    fl = GRAY_LIGHT if row3 % 2 == 0 else WHITE
    style_cell(ws3, f"A{row3}", student["serial"], font(9), fill(fl), align())
    style_cell(ws3, f"B{row3}", f"القاعة {student['hallCode']}", font(10, bold=True), fill(fl), align())
    style_cell(ws3, f"C{row3}", student["sourceHall"], font(9, color="555555"), fill(fl), align())
    style_cell(ws3, f"D{row3}", student["seatNumber"], font(9), fill(fl), align())
    style_cell(ws3, f"E{row3}", student["studentNumber"], font(9, color="555555"), fill(fl), align())
    style_cell(ws3, f"F{row3}", student["name"], font(10), fill(fl), align("right", "center"))
    style_cell(ws3, f"G{row3}", student["phone"], font(9, color="555555"), fill(fl), align())
    style_cell(ws3, f"H{row3}", "-", font(9, color="888888"), fill(fl), align())
    row3 += 1

set_col_widths(ws3, [8, 14, 16, 8, 18, 34, 18, 24])
ws3.freeze_panes = "A3"

# =====================================================================
# SHEET 4: ملخص القاعات (Hall Summary / Aggregation)
# =====================================================================
ws4 = wb.create_sheet(title="ملخص القاعات")
ws4.sheet_properties.tabColor = EMERALD
apply_rtl(ws4)

ws4.merge_cells("A1:H1")
style_cell(ws4, "A1", "ملخص أداء وحضور القاعات الـ 28 (101-109، 201-210، 301-309) — يتم التحديث تلقائياً بالمعادلات من ورقة رصد الغياب", font(12, True, WHITE), fill(NAVY), align())
set_row_height(ws4, 1, 26)

h4 = ["رمز القاعة", "اسم القاعة", "العدد الفعلي للطلاب", "الحاضرون", "الغائبون", "إجمالي المرصود", "نسبة الحضور", "حالة الرصد"]
for ci, h in enumerate(h4, start=1):
    style_cell(ws4, f"{get_column_letter(ci)}2", h, font(10, True, WHITE), fill(NAVY), align(), header_border)
set_row_height(ws4, 2, 24)

LR = last_row
for i, hall in enumerate(HALLS, start=3):
    hc = f"القاعة {hall}"
    fl = GRAY_LIGHT if i % 2 == 0 else WHITE
    style_cell(ws4, f"A{i}", int(hall), font(10), fill(fl), align())
    style_cell(ws4, f"B{i}", hc, font(10, bold=True), fill(fl), align("right", "center"))
    style_cell(ws4, f"C{i}", ACTUAL_COUNTS[hall], font(10), fill(fl), align())
    style_cell(ws4, f"D{i}", f'=COUNTIFS(\'رصد الغياب اليومي\'!$D$3:$D${LR},B{i},\'رصد الغياب اليومي\'!$G$3:$G${LR},"حاضر")', font(10, True, EMERALD), fill(fl), align())
    style_cell(ws4, f"E{i}", f'=COUNTIFS(\'رصد الغياب اليومي\'!$D$3:$D${LR},B{i},\'رصد الغياب اليومي\'!$G$3:$G${LR},"غائب")', font(10, True, ROSE), fill(fl), align())
    style_cell(ws4, f"F{i}", f'=D{i}+E{i}', font(10), fill(fl), align())
    c = style_cell(ws4, f"G{i}", f'=IF(F{i}=0,0,D{i}/F{i})', font(10, True, GOLD), fill(fl), align())
    c.number_format = "0.0%"
    style_cell(ws4, f"H{i}", f'=IF(F{i}>=C{i},"مرصودة",IF(F{i}>0,"جزئي","غير مرصودة"))', font(9, color="555555"), fill(fl), align())
    set_row_height(ws4, i, 20)

total_row = i + 1
style_cell(ws4, f"A{total_row}", "الإجمالي", font(11, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws4, f"B{total_row}", "-", font(10), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws4, f"C{total_row}", f"=SUM(C3:C{i})", font(11, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws4, f"D{total_row}", f"=SUM(D3:D{i})", font(11, True, EMERALD), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws4, f"E{total_row}", f"=SUM(E3:E{i})", font(11, True, ROSE), fill(GOLD_LIGHT), align(), total_border)
style_cell(ws4, f"F{total_row}", f"=SUM(F3:F{i})", font(11, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
c = style_cell(ws4, f"G{total_row}", f'=IF(F{total_row}=0,0,D{total_row}/F{total_row})', font(11, True, GOLD), fill(GOLD_LIGHT), align(), total_border)
c.number_format = "0.0%"
style_cell(ws4, f"H{total_row}", f'=COUNTIF(H3:H{i},"مرصودة") & "/28"', font(11, True, NAVY), fill(GOLD_LIGHT), align(), total_border)
set_row_height(ws4, total_row, 26)

set_col_widths(ws4, [12, 16, 10, 12, 12, 14, 14, 14])
ws4.freeze_panes = "A3"

# =====================================================================
# SHEET 5: دليل الاستخدام (Guide)
# =====================================================================
ws5 = wb.create_sheet(title="دليل الاستخدام")
ws5.sheet_properties.tabColor = ROSE
apply_rtl(ws5)

ws5.merge_cells("A1:D1")
style_cell(ws5, "A1", "دليل استخدام ملف سجل الغياب الإلكتروني", font(14, True, WHITE), fill(NAVY), align())
set_row_height(ws5, 1, 30)

guide = [
    ("كيف يعمل هذا الملف؟", "الملف مقسم لخمس أوراق عمل: لوحة التحكم (ملخصات ومؤشرات فورية)، رصد الغياب اليومي (إدخال الحضور والغياب)، قوائم الطلاب (دليل الطلاب المسجلين بالـ 28 قاعة: 101-109 بالدور الأول، 201-210 بالدور الثاني، 301-309 بالدور الثالث)، ملخص القاعات (تجميع تلقائي بالمعادلات)، وهذا الدليل."),
    ("طريقة تسجيل الحضور والغياب اليومي", "افتح ورقة «رصد الغياب اليومي» وحدد الطالب ثم اختر «حاضر» أو «غائب» من القائمة المنسدلة في عمود حالة الحضور، واكتب التاريخ والوقت واسم المشرف، وأضف ملاحظة عند الحاجة مثل عذر طبي أو استئذان."),
    ("المعادلات الإحصائية تعمل تلقائياً", "جميع الملخصات (المجموع، عدد الحاضرين والغائبين، نسبة الحضور، مؤشرات لوحة التحكم) مبنية بمعادلات SUM و COUNTIF و COUNTA — لا تعدّل خلايا الملخصات الملونة بل اعتمد على التحديث التلقائي."),
    ("طريقة نسخ الملف إلى Google Sheets", "افتح Google Drive > اضغط جديد > تحميل ملف > اختر هذا الملف، وسيتم تحويله إلى Google Sheets مع الحفاظ على كل المعادلات والتنسيقات. يمكنك مشاركته مع المشرفين ومنحهم صلاحية التحرير."),
    ("ربط النموذج بنظام Google Sites مثل صورة التطبيق", "يمكنك ربط هذا الشيت بـ Google Form (إدراج > نموذج) فيكون لكل طالب خيار تسجيل، ثم تضمين الشيت أو الفورم داخل موقعك على sites.google.com تماماً مثل النظام المعروض في الصورة."),
    ("طباعة وتصدير التقارير", "جميع الأوراق مهيأة للطباعة بالعرض تلقائياً مع احتواء الصفحة، ومن قائمة ملف يمكنك تصدير أي ورقة بصيغة PDF بضغطة واحدة."),
    ("إضافة أو تعديل طلاب وقاعات", "لتعديل قوائم الطلاب افتح ورقة «قوائم الطلاب»، ولإضافة قاعات جديدة عدّل ورقة «ملخص القاعات» واسحب معادلات التجميع على الصفوف الجديدة."),
    ("الألوان ودلالاتها", "الأزرق الكحلي: العناوين الرسمية | الذهبي: الملخصات والنسب | الأخضر: الحضور الإيجابي | الوردي/الأحمر: الغياب والتنبيهات | الرمادي الفاتح: بيانات عادية."),
]

row5 = 3
for g_idx, (gt, gb) in enumerate(guide, start=1):
    ws5.merge_cells(start_row=row5, start_column=1, end_row=row5, end_column=4)
    style_cell(ws5, f"A{row5}", f"{g_idx}. {gt}", font(11, True, NAVY), fill(GOLD_LIGHT), align("right", "center"))
    set_row_height(ws5, row5, 24)
    row5 += 1
    ws5.merge_cells(start_row=row5, start_column=1, end_row=row5, end_column=4)
    style_cell(ws5, f"A{row5}", gb, font(10, color="333333"), fill(WHITE), align("right", "top"))
    set_row_height(ws5, row5, 46)
    row5 += 2

set_col_widths(ws5, [14, 28, 28, 44])

# ----------------- Save -----------------
out = "/home/ubuntu/absencereg/client/public/سجل_الغياب_اليومي_للقاعات_28.xlsx"
wb.save(out)
print("SAVED", out)
