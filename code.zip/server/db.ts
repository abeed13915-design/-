import { and, desc, eq, gte, inArray, like, lte, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  AttendanceRecord,
  attendanceRecords,
  attendanceSessions,
  AttendanceSession,
  Hall,
  halls,
  InsertUser,
  Setting,
  settings,
  Student,
  students,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    throw new Error("Database is not available");
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export async function getSettings(): Promise<Record<string, string>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db.select().from(settings);
  const out: Record<string, string> = {};
  for (const r of rows) out[r.settingKey] = r.settingValue;
  return out;
}

export async function setSetting(settingKey: string, settingValue: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .insert(settings)
    .values({ settingKey, settingValue })
    .onDuplicateKeyUpdate({ set: { settingValue, updatedAt: new Date() } });
}

// ---------------------------------------------------------------------------
// Halls
// ---------------------------------------------------------------------------

export async function listHalls(): Promise<Array<Hall & { studentCount: number }>> {
  const db = await getDb();
  if (!db) return [];
  const hallList = await db
    .select()
    .from(halls)
    .where(eq(halls.isActive, true))
    .orderBy(halls.displayOrder);

  if (hallList.length === 0) return [];

  const counts = await db
    .select({
      hallId: students.hallId,
      cnt: sql<number>`count(*)`.mapWith(Number),
    })
    .from(students)
    .where(eq(students.isActive, true))
    .groupBy(students.hallId);

  const countMap = new Map<number, number>();
  for (const c of counts) countMap.set(c.hallId, c.cnt);

  return hallList.map((h) => ({
    ...h,
    studentCount: countMap.get(h.id) ?? h.capacity,
  }));
}

export async function getHallById(hallId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(halls).where(eq(halls.id, hallId)).limit(1);
  return rows[0];
}

// ---------------------------------------------------------------------------
// Students
// ---------------------------------------------------------------------------

export async function getStudentsForHall(hallId: number): Promise<Student[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(students)
    .where(and(eq(students.hallId, hallId), eq(students.isActive, true)))
    .orderBy(students.seatNumber, students.fullName);
}

export async function searchStudents(opts: { search?: string; hallId?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(students.isActive, true)];
  if (opts.hallId) conditions.push(eq(students.hallId, opts.hallId));
  if (opts.search && opts.search.trim()) {
    const q = `%${opts.search.trim()}%`;
    conditions.push(or(like(students.fullName, q), like(students.studentNumber, q))!);
  }
  return db
    .select()
    .from(students)
    .where(and(...conditions))
    .limit(opts.limit ?? 200);
}

// ---------------------------------------------------------------------------
// Attendance Sessions & Records
// ---------------------------------------------------------------------------

export async function getSessionWithRecords(opts: { hallId: number; sessionDate: string }) {
  const db = await getDb();
  if (!db) return null;

  const [session] = await db
    .select()
    .from(attendanceSessions)
    .where(and(eq(attendanceSessions.hallId, opts.hallId), eq(attendanceSessions.sessionDate, opts.sessionDate)))
    .limit(1);

  if (!session) return null;

  const records = await db
    .select()
    .from(attendanceRecords)
    .where(eq(attendanceRecords.sessionId, session.id));

  return { session, records };
}

export async function saveAttendanceSession(payload: {
  hallId: number;
  sessionDate: string;
  recordedTime?: string;
  savedBy?: string;
  records: Array<{ studentId: number; status: "present" | "absent"; notes?: string }>;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const total = payload.records.length;
  const absent = payload.records.filter((r) => r.status === "absent").length;
  const present = total - absent;

  const [existing] = await db
    .select()
    .from(attendanceSessions)
    .where(
      and(
        eq(attendanceSessions.hallId, payload.hallId),
        eq(attendanceSessions.sessionDate, payload.sessionDate)
      )
    )
    .limit(1);

  let sessionId: number;
  if (existing) {
    sessionId = existing.id;
    await db
      .update(attendanceSessions)
      .set({
        recordedTime: payload.recordedTime ?? existing.recordedTime,
        presentCount: present,
        absentCount: absent,
        totalCount: total,
        savedBy: payload.savedBy ?? existing.savedBy,
        updatedAt: new Date(),
      })
      .where(eq(attendanceSessions.id, existing.id));

    // Delete existing records to re-write fresh
    await db.delete(attendanceRecords).where(eq(attendanceRecords.sessionId, existing.id));
  } else {
    const res = await db.insert(attendanceSessions).values({
      hallId: payload.hallId,
      sessionDate: payload.sessionDate,
      recordedTime: payload.recordedTime,
      presentCount: present,
      absentCount: absent,
      totalCount: total,
      savedBy: payload.savedBy,
    });
    sessionId = Number((res as unknown as [{ insertId?: number }])[0]?.insertId ?? 0);
    if (!sessionId) {
      const [re] = await db
        .select({ id: attendanceSessions.id })
        .from(attendanceSessions)
        .where(
          and(
            eq(attendanceSessions.hallId, payload.hallId),
            eq(attendanceSessions.sessionDate, payload.sessionDate)
          )
        )
        .limit(1);
      sessionId = re!.id;
    }
  }

  if (payload.records.length > 0) {
    const rows = payload.records.map((r) => ({
      sessionId,
      studentId: r.studentId,
      status: r.status,
      notes: r.notes ?? null,
    }));
    const chunk = 150;
    for (let i = 0; i < rows.length; i += chunk) {
      await db.insert(attendanceRecords).values(rows.slice(i, i + chunk));
    }
  }

  return { sessionId, present, absent, total };
}

// ---------------------------------------------------------------------------
// Listing & Statistics
// ---------------------------------------------------------------------------

export async function listSessions(opts: {
  date?: string;
  hallId?: number;
  fromDate?: string;
  toDate?: string;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  const conds = [];
  if (opts.date) conds.push(eq(attendanceSessions.sessionDate, opts.date));
  if (opts.hallId) conds.push(eq(attendanceSessions.hallId, opts.hallId));
  if (opts.fromDate) conds.push(gte(attendanceSessions.sessionDate, opts.fromDate));
  if (opts.toDate) conds.push(lte(attendanceSessions.sessionDate, opts.toDate));

  const whereClause = conds.length > 0 ? and(...conds) : undefined;

  const rows = await db
    .select({
      id: attendanceSessions.id,
      sessionDate: attendanceSessions.sessionDate,
      recordedTime: attendanceSessions.recordedTime,
      presentCount: attendanceSessions.presentCount,
      absentCount: attendanceSessions.absentCount,
      totalCount: attendanceSessions.totalCount,
      savedBy: attendanceSessions.savedBy,
      createdAt: attendanceSessions.createdAt,
      hallId: halls.id,
      hallCode: halls.code,
      hallName: halls.name,
      hallCapacity: halls.capacity,
    })
    .from(attendanceSessions)
    .innerJoin(halls, eq(attendanceSessions.hallId, halls.id))
    .where(whereClause)
    .orderBy(desc(attendanceSessions.sessionDate), halls.displayOrder)
    .limit(opts.limit ?? 200);

  return rows;
}

export async function getSessionDetails(sessionId: number) {
  const db = await getDb();
  if (!db) return null;

  const [session] = await db
    .select({
      id: attendanceSessions.id,
      sessionDate: attendanceSessions.sessionDate,
      recordedTime: attendanceSessions.recordedTime,
      presentCount: attendanceSessions.presentCount,
      absentCount: attendanceSessions.absentCount,
      totalCount: attendanceSessions.totalCount,
      savedBy: attendanceSessions.savedBy,
      hallId: halls.id,
      hallCode: halls.code,
      hallName: halls.name,
      hallCapacity: halls.capacity,
      createdAt: attendanceSessions.createdAt,
    })
    .from(attendanceSessions)
    .innerJoin(halls, eq(attendanceSessions.hallId, halls.id))
    .where(eq(attendanceSessions.id, sessionId))
    .limit(1);

  if (!session) return null;

  const records = await db
    .select({
      recordId: attendanceRecords.id,
      status: attendanceRecords.status,
      notes: attendanceRecords.notes,
      studentId: students.id,
      studentNumber: students.studentNumber,
      fullName: students.fullName,
      seatNumber: students.seatNumber,
    })
    .from(attendanceRecords)
    .innerJoin(students, eq(attendanceRecords.studentId, students.id))
    .where(eq(attendanceRecords.sessionId, sessionId))
    .orderBy(students.seatNumber, students.fullName);

  return { session, records };
}

export async function getStatistics(opts: {
  date?: string;
  hallId?: number;
  fromDate?: string;
  toDate?: string;
}) {
  const db = await getDb();
  if (!db) {
    return {
      totalHalls: 28,
      totalStudents: 700,
      recordedSessions: 0,
      presentCount: 0,
      absentCount: 0,
      attendanceRate: 0,
      absenceRate: 0,
      dailyTrend: [],
      hallBreakdown: [],
    };
  }

  const conds = [];
  if (opts.date) conds.push(eq(attendanceSessions.sessionDate, opts.date));
  if (opts.hallId) conds.push(eq(attendanceSessions.hallId, opts.hallId));
  if (opts.fromDate) conds.push(gte(attendanceSessions.sessionDate, opts.fromDate));
  if (opts.toDate) conds.push(lte(attendanceSessions.sessionDate, opts.toDate));
  const whereClause = conds.length > 0 ? and(...conds) : undefined;

  const [hallCnt] = await db
    .select({ c: sql<number>`count(*)`.mapWith(Number) })
    .from(halls)
    .where(eq(halls.isActive, true));
  const [stuCnt] = await db
    .select({ c: sql<number>`count(*)`.mapWith(Number) })
    .from(students)
    .where(eq(students.isActive, true));

  const [agg] = await db
    .select({
      sessions: sql<number>`count(*)`.mapWith(Number),
      present: sql<number>`coalesce(sum(${attendanceSessions.presentCount}), 0)`.mapWith(Number),
      absent: sql<number>`coalesce(sum(${attendanceSessions.absentCount}), 0)`.mapWith(Number),
      total: sql<number>`coalesce(sum(${attendanceSessions.totalCount}), 0)`.mapWith(Number),
    })
    .from(attendanceSessions)
    .where(whereClause);

  const present = agg?.present ?? 0;
  const absent = agg?.absent ?? 0;
  const total = agg?.total ?? 0;
  const attendanceRate = total > 0 ? Math.round((present / total) * 1000) / 10 : 0;
  const absenceRate = total > 0 ? Math.round((absent / total) * 1000) / 10 : 0;

  // hall breakdown
  const hallAgg = await db
    .select({
      hallId: halls.id,
      code: halls.code,
      name: halls.name,
      capacity: halls.capacity,
      sessions: sql<number>`count(${attendanceSessions.id})`.mapWith(Number),
      present: sql<number>`coalesce(sum(${attendanceSessions.presentCount}), 0)`.mapWith(Number),
      absent: sql<number>`coalesce(sum(${attendanceSessions.absentCount}), 0)`.mapWith(Number),
      total: sql<number>`coalesce(sum(${attendanceSessions.totalCount}), 0)`.mapWith(Number),
    })
    .from(halls)
    .leftJoin(attendanceSessions, eq(attendanceSessions.hallId, halls.id))
    .where(
      opts.date
        ? and(eq(halls.isActive, true), eq(attendanceSessions.sessionDate, opts.date))
        : eq(halls.isActive, true)
    )
    .groupBy(halls.id)
    .orderBy(halls.displayOrder);

  // daily trend (last 14 days)
  const daily = await db
    .select({
      sessionDate: attendanceSessions.sessionDate,
      present: sql<number>`sum(${attendanceSessions.presentCount})`.mapWith(Number),
      absent: sql<number>`sum(${attendanceSessions.absentCount})`.mapWith(Number),
      total: sql<number>`sum(${attendanceSessions.totalCount})`.mapWith(Number),
    })
    .from(attendanceSessions)
    .groupBy(attendanceSessions.sessionDate)
    .orderBy(desc(attendanceSessions.sessionDate))
    .limit(14);

  return {
    totalHalls: hallCnt?.c ?? 28,
    totalStudents: stuCnt?.c ?? 700,
    recordedSessions: agg?.sessions ?? 0,
    presentCount: present,
    absentCount: absent,
    totalRecorded: total,
    attendanceRate,
    absenceRate,
    hallBreakdown: hallAgg.map((h) => ({
      ...h,
      rate: h.total > 0 ? Math.round((h.present / h.total) * 1000) / 10 : 0,
    })),
    dailyTrend: daily.reverse().map((d) => ({
      ...d,
      rate: d.total > 0 ? Math.round((d.present / d.total) * 1000) / 10 : 0,
    })),
  };
}

// ---------------------------------------------------------------------------
// Student CRUD
// ---------------------------------------------------------------------------

export async function addStudent(data: {
  studentNumber: string;
  fullName: string;
  hallId: number;
  seatNumber?: number;
  phone?: string;
  email?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(students).values({
    ...data,
    isActive: true,
  });
}

export async function updateStudent(
  id: number,
  data: {
    studentNumber?: string;
    fullName?: string;
    hallId?: number;
    seatNumber?: number | null;
    phone?: string | null;
    email?: string | null;
    notes?: string | null;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(students).set(data).where(eq(students.id, id));
}

export async function softDeleteStudent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(students).set({ isActive: false }).where(eq(students.id, id));
}

export async function deleteAttendanceSession(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(attendanceRecords).where(eq(attendanceRecords.sessionId, sessionId));
  await db.delete(attendanceSessions).where(eq(attendanceSessions.id, sessionId));
}
