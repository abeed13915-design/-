import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { attendanceRecords, attendanceSessions, halls, students } from "../drizzle/schema";

async function run() {
  const c = await mysql.createConnection(process.env.DATABASE_URL!);
  const db = drizzle(c);
  const [h] = await db.select().from(halls).where(eq(halls.code, "101")).limit(1);
  if (!h) {
    console.log("hall 101 not found");
    await c.end();
    return;
  }
  const stus = await db
    .select()
    .from(students)
    .where(and(eq(students.hallId, h.id), eq(students.isActive, true)))
    .orderBy(students.seatNumber);
  const absentIdx = new Set([3, 8, 14, 21]); // 4 absent
  const rows = stus.map((s, i) => ({
    studentId: s.id,
    status: absentIdx.has(i) ? ("absent" as const) : ("present" as const),
  }));
  const res = await db.insert(attendanceSessions).values({
    hallId: h.id,
    sessionDate: "2026-11-06",
    recordedTime: "08:13 م",
    presentCount: 21,
    absentCount: 4,
    totalCount: 25,
    savedBy: "المشرف",
  });
  const sid = (res as unknown as [{ insertId: number }])[0].insertId;
  await db.insert(attendanceRecords).values(
    rows.map((r) => ({ sessionId: sid, studentId: r.studentId, status: r.status }))
  );
  console.log("Sample session seeded id:", sid);
  await c.end();
}

run().catch(console.error);
