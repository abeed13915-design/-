import mysql from "mysql2/promise";
import { readFile, mkdir, writeFile } from "node:fs/promises";

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) throw new Error("DATABASE_URL is required");

const backupPath = "/home/ubuntu/absencereg/backups/roster-before-import.json";
const rosterPath = "/home/ubuntu/absencereg/backups/attached-roster.json";
const roster = JSON.parse(await readFile(rosterPath, "utf8")) as Array<{
  serial: number;
  name: string;
  sourceHall: string;
  studentNumber: string;
  phone: string;
  hallCode: string;
  seatNumber: number;
}>;

if (roster.length !== 889) throw new Error(`Expected 889 students, found ${roster.length}`);

const connection = await mysql.createConnection(dbUrl);
await connection.beginTransaction();
try {
  const [oldStudents] = await connection.query("SELECT * FROM students ORDER BY id");
  await mkdir("/home/ubuntu/absencereg/backups", { recursive: true });
  await writeFile(backupPath, JSON.stringify(oldStudents, null, 2), "utf8");

  // Clear sample attendance so it cannot remain attached to unrelated imported students.
  await connection.query("DELETE FROM attendanceRecords");
  await connection.query("DELETE FROM attendanceSessions");
  await connection.query("DELETE FROM students");

  for (const s of roster) {
    await connection.query(
      `INSERT INTO students (studentNumber, fullName, hallId, seatNumber, phone, email, notes)
       SELECT ?, ?, h.id, ?, ?, ?, ? FROM halls h WHERE h.code = ? LIMIT 1`,
      [s.studentNumber, s.name, s.seatNumber, s.phone || null, null, `المجموعة الأصلية: ${s.sourceHall}`, s.hallCode]
    );
  }

  await connection.commit();
  const [countRows] = await connection.query("SELECT COUNT(*) AS count FROM students WHERE isActive = 1");
  console.log("Imported students:", countRows);
  console.log("Backup:", backupPath);
} catch (error) {
  await connection.rollback();
  throw error;
} finally {
  await connection.end();
}
