import mysql from "mysql2/promise";

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection(dbUrl);
await connection.query("UPDATE halls SET capacity = 39 WHERE isActive = 1");
const [rows] = await connection.query("SELECT code, capacity FROM halls WHERE isActive = 1 ORDER BY displayOrder");
console.log("Updated halls:", rows);
await connection.end();
