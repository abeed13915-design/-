import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { eq } from "drizzle-orm";
import { halls, students } from "../drizzle/schema";

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) throw new Error("DATABASE_URL required");

const conn = await mysql.createConnection(dbUrl);
const db = drizzle(conn);

// Mapping from old code -> new code, new name, new floor
const MAPPING: Record<string, { code: string; name: string; floor: string }> = {};

for (let i = 110; i <= 119; i++) {
  const newNum = 201 + (i - 110);
  MAPPING[String(i)] = {
    code: String(newNum),
    name: `القاعة ${newNum}`,
    floor: "الدور الثاني",
  };
}

for (let i = 120; i <= 128; i++) {
  const newNum = 301 + (i - 120);
  MAPPING[String(i)] = {
    code: String(newNum),
    name: `القاعة ${newNum}`,
    floor: "الدور الثالث",
  };
}

console.log("==> Renaming halls...");
for (const [oldCode, target] of Object.entries(MAPPING)) {
  const [h] = await db.select().from(halls).where(eq(halls.code, oldCode)).limit(1);
  if (!h) {
    console.log(`hall ${oldCode} not found, skip`);
    continue;
  }
  await db
    .update(halls)
    .set({ code: target.code, name: target.name, floor: target.floor })
    .where(eq(halls.id, h.id));

  // update student numbers like STD-110-01 -> STD-201-01
  const oldPrefix = `STD-${oldCode}-`;
  const newPrefix = `STD-${target.code}-`;
  await conn.query(
    "UPDATE students SET studentNumber = CONCAT(?, SUBSTRING(studentNumber, ?)) WHERE hallId = ? AND studentNumber LIKE ?",
    [newPrefix, oldPrefix.length + 1, h.id, `${oldPrefix}%`]
  );
  console.log(`Renamed hall ${oldCode} -> ${target.code}`);
}

// Ensure 101-109 have floor label الدور الأول
for (let i = 101; i <= 109; i++) {
  await conn.query("UPDATE halls SET floor = ? WHERE code = ?", ["الدور الأول", String(i)]);
}

console.log("==> Verifying final hall list:");
const [rows] = await conn.query("SELECT code, name, floor, (SELECT count(*) FROM students s WHERE s.hallId = h.id and s.isActive = 1) cnt FROM halls h ORDER BY displayOrder ASC");
for (const r of rows as Array<{ code: string; name: string; floor: string; cnt: number }>) {
  console.log(r.code, r.name, r.floor, r.cnt);
}

await conn.end();
console.log("==> Done");
