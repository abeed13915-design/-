import { describe, expect, it } from "vitest";
import * as db from "./db";

describe("attendance database layer", () => {
  it("lists all 28 active halls with student counts", async () => {
    const halls = await db.listHalls();
    expect(halls.length).toBe(28);
    expect(halls[0].code).toBe("101");
    expect(halls[0].name).toBe("القاعة 101");
    expect(halls[0].studentCount).toBe(25);
  });

  it("returns 25 students for hall 101", async () => {
    const halls = await db.listHalls();
    const students = await db.getStudentsForHall(halls[0].id);
    expect(students.length).toBe(25);
    expect(students[0].fullName.length).toBeGreaterThan(3);
    expect(students[0].studentNumber).toMatch(/^STD-101-\d{2}$/);
  });

  it("saves and retrieves an attendance session with records", async () => {
    const halls = await db.listHalls();
    const hallId = halls[1].id; // hall 102
    const students = await db.getStudentsForHall(hallId);
    const records = students.map((s, i) => ({
      studentId: s.id,
      status: (i < 3 ? "absent" : "present") as "absent" | "present",
      notes: i === 0 ? "عذر طبي" : undefined,
    }));

    const result = await db.saveAttendanceSession({
      hallId,
      sessionDate: "2026-11-06",
      recordedTime: "09:00 ص",
      savedBy: "اختبار",
      records,
    });

    expect(result.absent).toBe(3);
    expect(result.present).toBe(students.length - 3);
    expect(result.total).toBe(students.length);

    const loaded = await db.getSessionWithRecords({
      hallId,
      sessionDate: "2026-11-06",
    });
    expect(loaded).not.toBeNull();
    expect(loaded!.records.length).toBe(students.length);
    const absents = loaded!.records.filter((r) => r.status === "absent");
    expect(absents.length).toBe(3);
  });

  it("computes statistics correctly", async () => {
    const stats = await db.getStatistics({});
    expect(stats.totalHalls).toBe(28);
    expect(stats.totalStudents).toBe(700);
    expect(stats.recordedSessions).toBeGreaterThanOrEqual(1);
    expect(stats.attendanceRate).toBeGreaterThan(0);
    expect(stats.hallBreakdown.length).toBe(28);
  });
});
