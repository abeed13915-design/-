import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { halls, students, settings } from "../drizzle/schema";

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) {
  throw new Error("DATABASE_URL is required for seeding");
}

const connection = await mysql.createConnection(dbUrl);
const db = drizzle(connection);

const FIRST_NAMES = [
  "محمد", "أحمد", "عبدالله", "خالد", "عمر", "فيصل", "سلطان", "سعود", "فهد", "نايف",
  "عبدالعزيز", "إبراهيم", "يوسف", "راشد", "زياد", "طارق", "ماجد", "وليد", "ريان", "سلمان",
  "تركي", "حسام", "حمزة", "بسام", "مازن", "نواف", "مشعل", "فارس", "بدر", "أنس",
  "سارة", "نورة", "ريم", "لينا", "جود", "مها", "فاطمة", "مريم", "منيرة", "شهد",
  "غيداء", "لمى", "هند", "رزان", "دانة", "أسيل", "العنود", "الهنوف", "لجين", "يارا",
  "ديما", "حنين", "جنى", "ريناد", "تسنيم", "جمانة", "رغد", "خلود", "أثير", "شذى"
];

const LAST_NAMES = [
  "العتيبي", "القحطاني", "الحربي", "الشهري", "الزهراني", "الغامدي", "الدوسري", "الشمري",
  "العنزي", "المطيري", "السبيعي", "الرشيدي", "البلوي", "الخالدي", "القرني", "العمري",
  "الصاعدي", "المالكي", "السلمي", "الحارثي", "الجهني", "السفياني", "الفيفي", "السهلي",
  "الجابري", "المحمادي", "العوفي", "الثقفي", "الرويلي", "العسيري", "الشهراني", "الأنصاري",
  "الأحمدي", "الهاشمي", "القرشي", "الزبيدي", "الصاعدي", "المرواني", "الجهوري", "النعماني"
];

async function seed() {
  console.log("==> Checking existing data...");
  const [hallRows] = await connection.query("SELECT COUNT(*) AS c FROM halls");
  const count = (hallRows as Array<{ c: number }>)[0]?.c ?? 0;
  if (count > 0) {
    console.log(`Database already seeded with ${count} halls. Skipping seed.`);
    await connection.end();
    return;
  }

  console.log("==> Seeding settings...");
  const defaultSettings = [
    { settingKey: "system_title", settingValue: "سجل الغياب الإلكتروني" },
    { settingKey: "system_subtitle", settingValue: "رصد الحضور والغياب اليومي للقاعات الـ 28" },
    { settingKey: "organization_name", settingValue: "سجل الغياب الإلكتروني - Dior" },
    { settingKey: "crown_title", settingValue: "سجل الغياب" },
  ];
  for (const row of defaultSettings) {
    await connection.query(
      "INSERT INTO settings (settingKey, settingValue) VALUES (?, ?) ON DUPLICATE KEY UPDATE settingValue = VALUES(settingValue)",
      [row.settingKey, row.settingValue]
    );
  }

  console.log("==> Seeding 28 halls...");
  const hallValues = [];
  const hallCodes = [
    ...Array.from({ length: 9 }, (_, k) => ({ code: String(101 + k), floor: "الدور الأول" })),
    ...Array.from({ length: 10 }, (_, k) => ({ code: String(201 + k), floor: "الدور الثاني" })),
    ...Array.from({ length: 9 }, (_, k) => ({ code: String(301 + k), floor: "الدور الثالث" })),
  ];
  for (let k = 0; k < hallCodes.length; k++) {
    const { code, floor } = hallCodes[k];
    hallValues.push({
      code,
      name: `القاعة ${code}`,
      capacity: 39,
      floor,
      displayOrder: k + 1,
      notes: null,
      isActive: true,
    });
  }
  await db.insert(halls).values(hallValues);

  const [insertedHalls] = await connection.query("SELECT id, code FROM halls ORDER BY displayOrder ASC");
  const hallList = insertedHalls as Array<{ id: number; code: string }>;

  console.log("==> Seeding initial students (25 per hall x 28 halls = 700 students; hall capacity is 39)...");
  let firstIdx = 0;
  let lastIdx = 0;
  const studentValues = [];

  for (const h of hallList) {
    for (let s = 1; s <= 25; s++) {
      const fn = FIRST_NAMES[firstIdx % FIRST_NAMES.length];
      const ln = LAST_NAMES[lastIdx % LAST_NAMES.length];
      firstIdx += 3;
      lastIdx += 7;
      studentValues.push({
        studentNumber: `STD-${h.code}-${String(s).padStart(2, "0")}`,
        fullName: `${fn} ${ln}`,
        hallId: h.id,
        seatNumber: s,
        phone: null,
        email: null,
        notes: null,
        isActive: true,
      });
    }
  }

  // insert in chunks
  const chunkSize = 100;
  for (let i = 0; i < studentValues.length; i += chunkSize) {
    await db.insert(students).values(studentValues.slice(i, i + chunkSize));
  }

  console.log(`==> Done! Seeded ${hallList.length} halls and ${studentValues.length} students.`);
  await connection.end();
}

seed().catch((e) => {
  console.error("Seed failed:", e);
  process.exit(1);
});
