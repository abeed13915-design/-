import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  attendance: router({
    // Halls
    listHalls: publicProcedure.query(async () => {
      return db.listHalls();
    }),

    // Students of a hall
    hallStudents: publicProcedure
      .input(z.object({ hallId: z.number().int().positive() }))
      .query(async ({ input }) => {
        return db.getStudentsForHall(input.hallId);
      }),

    // Get saved session (if any) for a hall on a date
    sessionWithRecords: publicProcedure
      .input(
        z.object({
          hallId: z.number().int().positive(),
          sessionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        })
      )
      .query(async ({ input }) => {
        return db.getSessionWithRecords(input);
      }),

    // Save/update attendance session
    save: publicProcedure
      .input(
        z.object({
          hallId: z.number().int().positive(),
          sessionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          recordedTime: z.string().optional(),
          savedBy: z.string().optional(),
          records: z.array(
            z.object({
              studentId: z.number().int().positive(),
              status: z.enum(["present", "absent"]),
              notes: z.string().optional(),
            })
          ),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.saveAttendanceSession({
          ...input,
          savedBy: input.savedBy || ctx.user?.name || "مشرف الغياب",
        });
      }),

    // Sessions listing
    listSessions: publicProcedure
      .input(
        z
          .object({
            date: z.string().optional(),
            hallId: z.number().int().optional(),
            fromDate: z.string().optional(),
            toDate: z.string().optional(),
            limit: z.number().int().min(1).max(500).optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return db.listSessions(input ?? {});
      }),

    // Full session details (for modal/drill-down)
    sessionDetails: publicProcedure
      .input(z.object({ sessionId: z.number().int().positive() }))
      .query(async ({ input }) => {
        return db.getSessionDetails(input.sessionId);
      }),

    deleteSession: publicProcedure
      .input(z.object({ sessionId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.deleteAttendanceSession(input.sessionId);
        return { success: true };
      }),

    // Stats & reports
    stats: publicProcedure
      .input(
        z
          .object({
            date: z.string().optional(),
            hallId: z.number().int().optional(),
            fromDate: z.string().optional(),
            toDate: z.string().optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return db.getStatistics(input ?? {});
      }),

    // Students search & CRUD
    searchStudents: publicProcedure
      .input(
        z
          .object({
            search: z.string().optional(),
            hallId: z.number().int().optional(),
            limit: z.number().int().optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return db.searchStudents(input ?? {});
      }),

    addStudent: publicProcedure
      .input(
        z.object({
          studentNumber: z.string().min(1),
          fullName: z.string().min(2),
          hallId: z.number().int().positive(),
          seatNumber: z.number().int().optional(),
          phone: z.string().optional(),
          email: z.string().email().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.addStudent(input);
        return { success: true };
      }),

    updateStudent: publicProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          studentNumber: z.string().optional(),
          fullName: z.string().optional(),
          hallId: z.number().int().optional(),
          seatNumber: z.number().int().nullable().optional(),
          phone: z.string().nullable().optional(),
          email: z.string().email().nullable().optional(),
          notes: z.string().nullable().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateStudent(id, data);
        return { success: true };
      }),

    deleteStudent: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.softDeleteStudent(input.id);
        return { success: true };
      }),

    // Settings
    settings: publicProcedure.query(async () => {
      return db.getSettings();
    }),

    updateSetting: publicProcedure
      .input(z.object({ key: z.string().min(1), value: z.string() }))
      .mutation(async ({ input }) => {
        await db.setSetting(input.key, input.value);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
