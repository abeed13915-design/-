import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Lecture halls / classrooms (28 halls: 101 .. 128)
 */
export const halls = mysqlTable("halls", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(), // e.g. "101"
  name: varchar("name", { length: 128 }).notNull(), // e.g. "القاعة 101"
  capacity: int("capacity").default(25).notNull(),
  floor: varchar("floor", { length: 64 }),
  displayOrder: int("displayOrder").default(0).notNull(),
  notes: text("notes"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Hall = typeof halls.$inferSelect;
export type InsertHall = typeof halls.$inferInsert;

/**
 * Students enrolled in each hall
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  studentNumber: varchar("studentNumber", { length: 64 }).notNull().unique(), // e.g. "STD-101-01"
  fullName: varchar("fullName", { length: 191 }).notNull(),
  hallId: int("hallId").notNull(),
  seatNumber: int("seatNumber"),
  phone: varchar("phone", { length: 64 }),
  email: varchar("email", { length: 320 }),
  notes: text("notes"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Daily attendance session per hall (one per hall per date, can be overwritten on save)
 */
export const attendanceSessions = mysqlTable("attendanceSessions", {
  id: int("id").autoincrement().primaryKey(),
  sessionDate: varchar("sessionDate", { length: 10 }).notNull(), // "YYYY-MM-DD"
  hallId: int("hallId").notNull(),
  recordedTime: varchar("recordedTime", { length: 32 }), // e.g. "08:13 م"
  presentCount: int("presentCount").default(0).notNull(),
  absentCount: int("absentCount").default(0).notNull(),
  totalCount: int("totalCount").default(0).notNull(),
  savedBy: varchar("savedBy", { length: 191 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AttendanceSession = typeof attendanceSessions.$inferSelect;
export type InsertAttendanceSession = typeof attendanceSessions.$inferInsert;

/**
 * Attendance record for each student in a session
 */
export const attendanceRecords = mysqlTable("attendanceRecords", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  studentId: int("studentId").notNull(),
  status: mysqlEnum("status", ["present", "absent"]).default("present").notNull(),
  notes: varchar("notes", { length: 255 }),
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
});

export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type InsertAttendanceRecord = typeof attendanceRecords.$inferInsert;

/**
 * System settings (title, subtitle, luxury theme name, etc.)
 */
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 96 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
